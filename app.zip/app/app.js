'use strict';

/**
Copyright (C) 2017 Andras Sarvari <andras.sarvari@sarvaria.net>

Permission to use, copy, modify, and/or distribute this software for any
purpose with or without fee is hereby granted, provided that the above
copyright notice and this permission notice appear in all copies.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
*/

// Global constanses

global.CONST = {
    USER: {
        ID:                     'userid',
        NAME:                   'username',
        TOKEN:                  'token',
        DEFAULT_BORNDATE:       '1990.01.29',
        MOBILEINTERNET:         'mobileinternet'
    },
    SCREEN: {
        CURRENTSCREEN:          'currentscreen',
        PREVIOUSSCREEN:         'previousscreen',
        FADING_INTERVAL:        120,
        SWIPE_SENSITIVITY:      20,
        FAVORITES:              'favorites',
        SEARCH:                 'search',
        PROVIDER:               'provider',
        PROVIDERINFO:           'providerinfo',
        MAP:                    'map',
        FILTER:                 'filter',
        SETTINGS:               'settings',
        UNSUBSCRIBE:            'unsubscribedialog',
        BORNDATE:               'borndatedialog',
        SELECTEDPROVIDER:       'selectedprovider',
        FAVORITES_SORTTYPE:     'favoritessorttype',
        STORESELECTOR:          'storeselector'
    },
    BUTTON: {
        BACK:                   'back',
        SORTBYPOINT:            'sortbypoint',
        SORTBYALPHABET:         'sortbyalphabet',
        SETTINGS:               'settings'
    },
    EVENT: {
        BACK:                   'backbuttonselected',
        SORTBYPOINT:            'sortbypointbuttonselected',
        SORTBYALPHABET:         'sortbyalphabetbuttonselected',
        SETTINGS:               'settingsselected',
        CONTROL:                'controlbuttonselected',
        PROVIDER:               'providerselected',
        SEARCH:                 'showsearch',
        SHOWPROVIDERINFO:       'showproviderinfo',
        SUBSCRIBE:              'subscribe',
        UNSUBSCRIBE:            'unsubscribe',
        CANCEL:                 'cancel',
        SHOWFILTER:             'showfilter',
        SETBORNDATE:            'setborndate',
        SELECTSTORE:            'selectstore'
    },
    POINTREQUESTSTATE: {
        STATE:                  'requestpointstate',
        LOCATING:               'locating',
        OUTOFRANGE:             'outofrange',
        INRANGE:                'inrange',
        INPROGRESS:             'inprogress'
    },
    LOCALDATA: {
        BADGES:                 'badges'
    }
};
    
// Determining and loading the current locale

var locales = ['en', 'hu'];
var localeIndex = locales.indexOf(require('platform').device.language);
require('./locale/' + locales[localeIndex < 0 ? 0 : localeIndex] + '.js');

// Initializing the Firebase

var FirebaseController = require('./controller/firebase.js').FirebaseController;
global.firebaseController = new FirebaseController();

// Initializing the database

var DB = require('./controller/db.js').DB;
global.DB = new DB();

// Starting the first screen

require('application').start({ 
    moduleName: global.firebaseController.isLoggedIn() ? 
    'main-page' :
    './view/screen/login/login-page'
});
