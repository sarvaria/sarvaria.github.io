'use strict';

/**
Copyright (C) 2017 Andras Sarvari <andras.sarvari@sarvaria.net>

Permission to use, copy, modify, and/or distribute this software for any
purpose with or without fee is hereby granted, provided that the above
copyright notice and this permission notice appear in all copies.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
*/

global.locale = {
    language:                               'hu',
    applicationtitle:                       'PONTY',
    message: {
        error:                              'Nemvárt hiba történt az alkalmazásban. Próbálja újra!',
        login: {
            nointernet:                     'Bejelentkezni csak meglévő internet kapcsolat esetén lehetséges'
        }
    },
    screen: {
        login: {
            label1:                         'Adja meg a nevét',
            label2:                         'Nincs felhasználói név. Nincs jelszó.',
            label3:                         'Csak a neve',
            label4:                         'A neve a kiválasztott szolgáltatók',
            label5:                         'számára látható lesz.',
            label6:                         'Késöbb ezt megváltoztathatja',
            button:                         'Kezdjük',
            usernamerule:                   'A név minimum 4 karakterből kell álljon és nem tartalmazhat szóközt!'
        },
        map: {
            hours:                          'Nyitvatartás:',
            open:                           'Nyitva',
            close:                          'Zárva',
            address:                        'Cím:',
            phone:                          'Telefon:',
            populartimes:                   'Foglaltság',
            populartimesstate:              'Kissé foglalt',
            live:                           'ÉLŐ'            
        },
        notification: {
            title:                          'Értesítések',
            month: [
                                            'JAN',
                                            'FEB',
                                            'MÁR',
                                            'ÁPR',
                                            'MÁJ',
                                            'JÚN',
                                            'JÚL',
                                            'AUG',
                                            'SEP',
                                            'OCT',
                                            'NOV',
                                            'DEC'
            ]
        },
        search: {
            title:                          'Boltok Keresése',
            alldistricts:                   'Minden kerület',
            allkeywords:                    'Minden kulcsszó'
        },
        providerinfo: {
            title:                          'Boltok Keresése',
            hours:                          'Nyitvatartás:',
            open:                           'Nyitva',
            close:                          'Zárva',
            directions:                     'Út ide',
            website:                        'Honlap',
            address:                        'Cím:',
            phone:                          'Telefon:',
            populartimes:                   'Foglaltság',
            populartimesstate:              'Kissé foglalt',
            live:                           'ÉLŐ'            
        },
        filter: {
            title: {
                category:                   'Minden kategória',
                district:                   'Minden kerület',
                keyword:                    'Minden kulcsszó'
            }
        },
        favorites: {
            title:                          'Kedvenc Helyeim'
        },
        provider: {
            title:                          'Kedvenc Helyeim',
            freebie:                        'Freebie',
            puzzle:                         'Puzzle',
            total:                          'Összesen',
            requestpointlabel: {
                inrange:                    'Pont Kérés',
                outofrange:                 'Nincs a közelben. Újrapróbálhatod.',
                locating:                   'Helymeghatározás...',
                inprogress:                 'Folyamatban...'
            }             
        },
        settings: {
            title:                          'Beállítások',
            personaldata: {
                title:                      'Személyes adatok',
                username:                   'Név:',
                borndate:                   'Születési idő:'
            },
            network: {
                title:                      'Hálózat',
                mobileinternet:             'Mobil internet engedélyezése:'
            },
            notificationcategory: {
                title:                      'Értesítési kategóriák'
            },
            locationinterest: {
                title:                      'Helyek amik érdekelnek'
            },
            logout: {
                title:                      'Kijelentkezés',
                logout:                     'Kijelentkezés'
            }
        }
    }
};
