'use strict';

/**
Copyright (C) 2017 Andras Sarvari <andras.sarvari@sarvaria.net>

Permission to use, copy, modify, and/or distribute this software for any
purpose with or without fee is hereby granted, provided that the above
copyright notice and this permission notice appear in all copies.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
*/

global.locale = {
    language:                               'en',
    applicationtitle:                       'PONTY',
    message: {
        error:                              'Unexpected error occured. Try again!',
        login: {
            nointernet:                     'Login is not available if there is no internet connection'
        }
    },
    screen: {
        login: {
            label1:                         'Type your name',
            label2:                         'No username. No password.',
            label3:                         'Just your name.',
            label4:                         'The name you enter will be visible',
            label5:                         'to the providers you select.',
            label6:                         'You can change this later',
            button:                         'Get Started',
            usernamerule:                   'The username must be at least 4 characters long and can not contains space!'            
        },
        map: {
            hours:                          'Hours:',
            open:                           'Open now',
            close:                          'Closed',
            address:                        'Address:',
            phone:                          'Phone:',
            populartimes:                   'Popular times',
            populartimesstate:              'A little busy',
            live:                           'LIVE'         
        },
        notification: {
            title:                          'Notification',
            month: [
                                            'JAN',
                                            'FEB',
                                            'MAR',
                                            'APR',
                                            'MAJ',
                                            'JUN',
                                            'JUL',
                                            'AUG',
                                            'SEP',
                                            'OCT',
                                            'NOV',
                                            'DEC'
            ]
        },
        search: {
            title:                          'Provider Search',
            alldistricts:                   'All Districts',
            allkeywords:                    'All Keywords'
        },
        providerinfo: {
            title:                          'Provider Search',
            hours:                          'Hours:',
            open:                           'Open now',
            close:                          'Closed',
            directions:                     'Directions',
            website:                        'Website',
            address:                        'Address:',
            phone:                          'Phone:',
            populartimes:                   'Popular times',
            populartimesstate:              'A little busy',
            live:                           'LIVE'
        },
        filter: {
            title: {
                category:                   'All Categories',
                district:                   'All Districts',
                keyword:                    'All Keywords'
            }
        },
        favorites: {
            title:                          'My Favorite Places'
        },
        provider: {
            title:                          'My Favorite Places',
            freebie:                        'Freebie',
            puzzle:                         'Puzzle',
            total:                          'Total',
            requestpointlabel: {
                inrange:                    'Request a Point',
                outofrange:                 'Provider is out of range. Tap to retry.',
                locating:                   'Locating...',
                inprogress:                 'In progress...'
            }             
        },
        settings: {
            title:                          'Settings',
            personaldata: {
                title:                      'Personal data',
                username:                   'Username:',
                borndate:                   'Born date:'                
            },
            network: {
                title:                      'Network',
                mobileinternet:             'Enable mobile internet usage:'                
            },
            notificationcategory: {
                title:                      'Notification Category'
            },
            locationinterest: {
                title:                      'Location Interest'
            },
            logout: {
                title:                      'Logout',
                logout:                     'Log out'
            }
        }
    }
};
