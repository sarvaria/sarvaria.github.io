'use strict';

/**
Copyright (C) 2017 Andras Sarvari <andras.sarvari@sarvaria.net>

Permission to use, copy, modify, and/or distribute this software for any
purpose with or without fee is hereby granted, provided that the above
copyright notice and this permission notice appear in all copies.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
*/

// Loading required modules

var connectivity = require('connectivity');
var firebase = require('nativescript-plugin-firebase');
var settings = require('application-settings');

/**
 * Creates a new FirebaseController instance.
 * 
 * @param {Object} options  options of the constructor.
 */

var FirebaseController = function(options) {

    // Reference to the current object

    var self = this

    self.dbListeners = [];
};

/**
 * Initializes the Firebase if it not initialized yet.
 * 
 * @return  {Promise}   promise     promise of the initialization process
 */

FirebaseController.prototype.init = function() {

    // Reference to the current object

    var self = this

    // Initializing

    return new Promise(function(resolve, reject) {

        // There is nothing to do if the Firebase initialized already

        if (global.initialized) {
            resolve();
        } else {

            // Does the internet available?

            if (self.isInternetConnection(true)) {

                // Initializing the Firebase and using the offline database
                // feature.

                firebase.init({
                    //persist: true,
                }).then(function(instance) {

                    // Firebase initialized successfully

                    global.initialized = true;                                        
                    resolve();

                // Error occured during initialization

                }, function(error) {
                    reject(error);
                });
            } else {

                // There is no internet connection

                reject(global.locale.message.login.nointernet);
            }
        }
    });
};

/**
 * Initializes the Firebase Push Notification System.
 */

FirebaseController.prototype.initFCM = function() {

    // Registering the event that fires when a new token is assigned to this
    // device.

    firebase.getCurrentPushToken().then(function(token) {
        settings.setString(global.CONST.USER.TOKEN, token);
        var value = {};
        value[token] = settings.getString(global.CONST.USER.ID, '');
        firebase.setValue('/FCMtokensCustomers', value);
    });

    // Registering the event that fires when a new push notification received
    
    firebase.addOnMessageReceivedCallback(
        function(message) {
            if (message && message.body) {
                alert(message.body);
            }
        }
    );
};

/**
 * Registers the user after a successfull login.
 * 
 * @param   {Object}    user        user that has to register
 * @param   {Object}    username    name of the user
 */

FirebaseController.prototype.registerUser = function(user, username) {

    // Registering the user locally

    global.firebaseuser = user;
    settings.setString(global.CONST.USER.ID, user.uid);

    // Storing the name of the user in the Firebase DB

    firebase.setValue(
        '/customers/' + settings.getString(global.CONST.USER.ID) + '/displayName',
        username
    );

    // Storing the language code of the user in the Firebase DB

    firebase.setValue(
        '/customers/' + settings.getString(global.CONST.USER.ID) + '/lang',
        global.locale.language
    );
};

/**
 * Removes the user registration.
 * 
 * @param   {Object}    user    user that has to register
 */

FirebaseController.prototype.clearUser = function() {

    // Clearing user registration

    global.firebaseuser = undefined;
    settings.clear();
};

/**
 * General login for all authentication providers.
 * 
 * @param   {String}    loginType   type of the login
 * @param   {String}    username    name of the user
 * @return  {Promise}   promise     promise of the login process
 */

FirebaseController.prototype.login = function(loginType, username) {

    // Reference to the current object

    var self = this;

    // Setting login options

    var options = { type: loginType };
   
    // Login

    return new Promise(function(resolve, reject) {

        // Does the internet available?

        if (self.isInternetConnection(true)) {
            
            // Trying to get the current user

            firebase.getCurrentUser().then(function(user) {

                // Does the user information obtained?

                if (user) {

                    // Registering the user and callbacking

                    self.registerUser(user, username);
                    resolve(user);
                } else {

                    // Login by using the requested provider

                    firebase.login(options).then(function(user) {

                        // Does the user information obtained?

                        if (user) {

                            // Registering the user and callbacking

                            self.registerUser(user, username);
                            resolve(user);
                        } else {

                            // Login was unsuccessfull. Callbacking.
        
                            self.clearUser();
                            reject();
                        }
                    }, function(error) {

                        // Login was unsuccessfull. Callbacking.
        
                        self.clearUser();
                        reject(error);
                    });
                }

            // The obtaining of the current user was unsucessfull. Trying to
            // authenticate the user.

            }, function (error) {

                // Login by using the requested provider

                firebase.login(options).then(function(user) {

                    // Does the user information obtained?

                    if (user) {

                        // Registering the user and callbacking

                        self.registerUser(user, username);
                        resolve(user);
                    } else {

                        // Login was unsuccessfull. Callbacking.

                        self.clearUser();
                        reject();
                    }
                }, function(error) {

                    // Login was unsuccessfull. Callbacking.

                    self.clearUser();
                    reject(error);
                });
            });
        } else {

            // There is no internet connection

            reject(global.locale.message.login.nointernet);            
        }
    });
};

/**
 * Logouts the current user.
 */

FirebaseController.prototype.logout = function() {

    // Reference to the current object

    var self = this;

    // Clearing user registration

    self.clearUser();

    // Logouts the firebase user

    firebase.logout();
};

/**
 * Does the user logged in yet?
 * 
 * @return  {Boolean}   status  logged in status
 */

FirebaseController.prototype.isLoggedIn = function() {
    return settings.getString(global.CONST.USER.NAME) != undefined;
};

/**
 * Gets the name of the current user.
 * 
 * @return  {String}    username    name of the current user
 */

FirebaseController.prototype.getUserName = function() {
    return settings.getString(global.CONST.USER.NAME);
};

/**
 * Gets the Firebase instance.
 * 
 * @param   {Object}    firebase    firebase instance
 */

FirebaseController.prototype.getFirebase = function() {
    return firebase;
};

/**
 * Checks that the internet connection is available or not.
 * 
 * @param   {Boolean}   mobileinternet  status of the mobile internet usage
 * @return  {Boolean}   internet        internet connection available
 */

FirebaseController.prototype.isInternetConnection = function(mobileinternet) {

    // Getting the connection type

    var connectionType = connectivity.getConnectionType();

    // Returns the availibility of the internet

    return  connectionType == connectivity.connectionType.wifi || 
            (connectionType == connectivity.connectionType.mobile &&
            settings.getBoolean(
                global.CONST.USER.MOBILEINTERNET,
                (mobileinternet == undefined ? true : mobileinternet)
            ));
};

FirebaseController.prototype.query = function(options) {

    // Reference to the current object

    var self = this

    var listenerInfo;

    return new Promise(function(resolve, reject) {
        firebase.query(function(result) {
            resolve(result.value);
        }, options.path, {
            singleEvent: true,
            orderBy: {
                type: firebase.QueryOrderByType.VALUE,
                value: '/code'
            },
        });
        /*if (options.single) {
            firebase.addValueEventListener(function(result) {
                firebase.removeEventListeners(
                    listenerInfo.listener,            
                    listenerInfo.path
                );
                resolve(result.value);
            }, options.path).then(function(listenerWrapper) {
                listenerInfo = {
                    listener:   listenerWrapper.listeners,
                    path:       listenerWrapper.path
                };
            });
        } else if (options.childwatch) {
            firebase.addChildEventListener(function(result) {
                options.callback(result);
            }, options.path).then(function(listenerWrapper) {
                self.dbListeners.push({
                    listener:   listenerWrapper.listeners,
                    path:       listenerWrapper.path
                });
            });

            resolve();
        } else {
            firebase.addValueEventListener(function(result) {
                options.callback(result.value);
            }, options.path).then(function(listenerWrapper) {
                self.dbListeners.push({
                    listener:   listenerWrapper.listeners,
                    path:       listenerWrapper.path
                });
            });

            resolve();
        }*/
    });
};

FirebaseController.prototype.setValue = function(options) {
    console.log(options.path);
    console.log(options.value);
    firebase.setValue(options.path, options.value);
};

FirebaseController.prototype.removeDBListeners = function() {

    // Reference to the current object

    var self = this

    self.dbListeners.forEach(function(listenerInfo) {
        firebase.removeEventListeners(
            listenerInfo.listener,            
            listenerInfo.path
        );
    });
};
  
// Propagating the FirebaseController

exports.FirebaseController = FirebaseController;
