'use strict';

/**
Copyright (C) 2017 Andras Sarvari <andras.sarvari@sarvaria.net>

Permission to use, copy, modify, and/or distribute this software for any
purpose with or without fee is hereby granted, provided that the above
copyright notice and this permission notice appear in all copies.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
*/

// Loading required modules

var imageSource = require('image-source');
var fs = require('file-system');

/**
 * Creates a new ProviderController instance.
 * 
 * @param {Object} options  options of the constructor.
 */

var ProviderController = function(options) {
};

/**
 * Loads the puzzle picture of the specified provider.
 * 
 * @return  {Promise}   promise     promise of the loading process
 */

ProviderController.prototype.loadPuzzlePicture = function() {
    var folder = fs.knownFolders.documents();
    var path = fs.path.join(folder.path, 'puzzlepicture.png');

    if (fs.File.exists(path)) {
        return new Promise(function(resolve, reject) {
            resolve(imageSource.fromFile(path));
        });
    } else {
        return this.savePuzzlePicture();
    }
};

ProviderController.prototype.savePuzzlePicture = function() {
    return new Promise(function(resolve, reject) {
        var folder = fs.knownFolders.documents();
        var path = fs.path.join(folder.path, 'puzzlepicture.png');
    
        if (fs.File.exists(path)) {
            resolve(imageSource.fromFile(path));
        } else {
            imageSource.fromUrl('http://portal.sarvaria.net/ponty/providerpicture.png').then(function(source) {
                source.saveToFile(path, 'png');
                resolve(imageSource.fromFile(path));
            }, function(error) {
                reject();
            });
        }
    });
};

// Propagating the ProviderController

exports.ProviderController = ProviderController;
