'use strict';

/**
Copyright (C) 2017 Andras Sarvari <andras.sarvari@sarvaria.net>

Permission to use, copy, modify, and/or distribute this software for any
purpose with or without fee is hereby granted, provided that the above
copyright notice and this permission notice appear in all copies.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
*/

// Loading required modules

var settings = require('application-settings');

/**
 * Creates a new DBr instance.
 * 
 * @param {Object} options  options of the constructor.
 */

var DB = function(options) {
};

/**
 * Loads the puzzle picture of the specified provider.
 * 
 * @return  {Promise}   promise     promise of the loading process
 */

DB.prototype.loadProviders = function() {
    return new Promise(function(resolve, reject) {

        // Preparing

        var providers = [];

        // Getting all of the providers from Firebase DB

        global.firebaseController.query({
            path: '/providers'
        }).then(function(result) {
            providers = [];
            
            for (var key in result) {
                if (result.hasOwnProperty(key)) {
                    var store = [];

                    if (result[key].stores) {
                        for (var storekey in result[key].stores) {
                            if (result[key].stores.hasOwnProperty(storekey)) {
                                result[key].stores[storekey].id = storekey;
                                store.push(result[key].stores[storekey]);
                            }
                        }
                    }

                    result[key].id = key;
                    result[key].selected = false;
                    result[key].store = store;

                    providers.push(result[key]);
                }
            }

            // Getting the registered providers from Firebase DB

            global.firebaseController.query({
                path: '/customers/' + settings.getString(global.CONST.USER.ID) + '/providers'
            }).then(function(result) {

                for (var key in result) {
                    if (result.hasOwnProperty(key)) {
                        for (var i = 0; i < providers.length; i++) {
                            if (providers[i].id == key) {
                                providers[i].selected = true;

                                for (var subkey in result[key]) {
                                    if (result[key].hasOwnProperty(subkey)) {
                                        providers[i][subkey] = result[key][subkey];
                                    }
                                }

                                break;
                            }
                        }
                    }
                }

                // Returning the providers

                resolve(providers);
            });
        });
    });        
};

DB.prototype.loadDistricts = function() {
    return new Promise(function(resolve, reject) {
        global.firebaseController.query({ path: '/locations' }).then(function(result) {
            var items = [];
    
            for (var key in result) {
                if (result.hasOwnProperty(key)) {
                    items.push({ id: key, name: result[key].city + (result[key].locales[global.locale.language] ? (', ' + result[key].locales[global.locale.language]) : ''), selected: false });
                }
            }

            items.sort(function(a, b) {
                if (a.name < b.name) {
                    return -1;
                } else if (a.name > b.name) {
                    return 1;
                } else {
                    return 0;
                }
            });
                
            resolve(items);
        });
    });
};

DB.prototype.loadKeywords = function(providerid, storeid) {
    return new Promise(function(resolve, reject) {
        global.firebaseController.query({
            path: '/keywords'
        }).then(function(result) {
            var keywords = [];

            for (var key in result[global.locale.language]) {
                if (result[global.locale.language].hasOwnProperty(key)) {
                    keywords.push({ id: key, name: key, selected: false });
                }
            }

            keywords.sort(function(a, b) {
                if (a.name < b.name) {
                    return -1;
                } else if (a.name > b.name) {
                    return 1;
                } else {
                    return 0;
                }
            });
            
            if (!providerid && !storeid) {
                resolve(keywords);
            } else {
                global.firebaseController.query({
                    path: '/providers/' + providerid + '/stores/' + storeid + '/keywords/' + global.locale.language
                }).then(function(result) {
                    for (var key in result) {
                        if (result.hasOwnProperty(key)) {
                            for (var i = 0; i < keywords.length; i++) {
                                if (keywords[i].name == key) {
                                    keywords[i].selected = true;
                                    break;
                                }
                            }
                        }
                    }

                    resolve(keywords);
                });
            }
        });
    });
};

DB.prototype.loadBadges = function() {
    return new Promise(function(resolve, reject) {
        global.firebaseController.query({
            path: '/badges'
        }).then(function(result) {
            resolve(result);
        });
    });
};

DB.prototype.loadNotifications = function() {
    return new Promise(function(resolve, reject) {
        global.firebaseController.query({
            path: '/customers/' + settings.getString(global.CONST.USER.ID) + '/notifications'
        }).then(function(result) {
            var notifications = [];

            for (var key in result) {
                if (result.hasOwnProperty(key)) {
                    result[key].id = key;

                    if (result[key].responseOptions) {
                        result[key].answer = [];

                        if (result[key].responseOptions.A) {
                            result[key].answer.push(result[key].responseOptions.A);
                        }

                        if (result[key].responseOptions.B) {
                            result[key].answer.push(result[key].responseOptions.B);
                        }

                        if (result[key].responseOptions.C) {
                            result[key].answer.push(result[key].responseOptions.C);
                        }

                        delete result[key].responseOptions
                    }

                    if (result[key].response && result[key].respondedAt) {
                        var index;

                        if (result[key].response == 'A') {
                            index = 0;
                        } else if (result[key].response == 'B') {
                            index = 1;
                        } else {
                            index = 2;                            
                        }

                        var date = new Date(result[key].respondedAt);
                        
                        result[key].answered = { 
                            time:   global.locale.screen.notification.month[date.getMonth()] + ' ' + date.getDate(),
                            index:  index
                        };

                        delete result[key].response;
                        delete result[key].respondedAt;
                    }
                    
                    result[key].question = result[key].body;
                    result[key].message = result[key].body;
                    delete result[key].body;
                    
                    var time = new Date(result[key].created);
                    result[key].time = global.locale.screen.notification.month[time.getMonth()] + ' ' + time.getDate();

                    result[key].icon = 'res://icon';
                    
                    notifications.push(result[key]);
                }
            }

            resolve(notifications);
        });
    });
};

// Propagating the DB

exports.DB = DB;
