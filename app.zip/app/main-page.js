'use strict';

/**
Copyright (C) 2017 Andras Sarvari <andras.sarvari@sarvaria.net>

Permission to use, copy, modify, and/or distribute this software for any
purpose with or without fee is hereby granted, provided that the above
copyright notice and this permission notice appear in all copies.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
*/

// Loading required modules

var application = require('application');
var settings = require('application-settings');
var enums = require('ui/enums');
var platform = require('platform');
var exitUtil = require('nativescript-exit');
var Geolocation = require('nativescript-geolocation');

// Declaring module level variables

var container;
var actionbar;
var controlbar;
var favoritesScreen;
var providerScreen;
var searchScreen;
var filterScreen;
var providerinfoScreen;
var mapScreen;
var settingsScreen;
var notificationScreen;
var currentLocation;

// BACK button handler

var backEvent = function(event) {

    // Does the BACK button available on the actionbar? If yes, showing the
    // previous screen. If not, exit from the application.

    if (actionbar.backButton) {
        controlbar.selectButton(settings.getString(global.CONST.SCREEN.PREVIOUSSCREEN));
    } else {
        exitUtil.exit();
    }

    // Do not do the original back functionality

    event.cancel = true;
};

/**
 * Event that fires when the main page has been loaded.
 * 
 * @param   event {Object}      event object
 */

exports.onLoaded = function(event) {

    // Getting the container
    
    container = event.object;

    // Getting device dimensions
    
    global.screenSize = {
        widthPX:    platform.screen.mainScreen.widthPixels,
        widthDP:    platform.screen.mainScreen.widthDIPs,
        heightPX:   platform.screen.mainScreen.heightPixels,
        heightDP:   platform.screen.mainScreen.heightDIPs
    };
    global.screenSize.DP = global.screenSize.widthPX /
                           global.screenSize.widthDP;

    // Reseting dialog states

    settings.remove(global.CONST.SCREEN.UNSUBSCRIBE);

    // Setting foreground color of the statusbar on android devices

    if (application.android) {
        application.android.startActivity.getWindow().getDecorView()
        .setSystemUiVisibility(
            android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        );
    }

    // Getting the referenced widgets in the container

    actionbar = container.getViewById('actionbar');
    controlbar = container.getViewById('controlbar');
    favoritesScreen = container.getViewById('favorites_screen');
    providerScreen = container.getViewById('provider_screen');
    searchScreen = container.getViewById('search_screen');
    filterScreen = container.getViewById('filter_screen');
    providerinfoScreen = container.getViewById('providerinfo_screen');
    mapScreen = container.getViewById('map_screen');
    settingsScreen = container.getViewById('settings_screen');
    notificationScreen = container.getViewById('notification_screen');
   
    // Initializing the local database

    global.db = {};
    
    // BACK button handler

    actionbar.on(global.CONST.EVENT.BACK, function() {
        controlbar.selectButton(settings.getString(global.CONST.SCREEN.PREVIOUSSCREEN));
    });

    // SORT BY POINT button handler

    actionbar.on(global.CONST.EVENT.SORTBYPOINT, function() {
        if (exports.getCurrentScreen() === global.CONST.SCREEN.FAVORITES) {
            settings.setString(
                global.CONST.SCREEN.FAVORITES_SORTTYPE,
                global.CONST.BUTTON.SORTBYALPHABET
            );
            actionbar.setLeftButton(global.CONST.BUTTON.SORTBYALPHABET);
            favoritesScreen.refresh(actionbar.getLeftButton());
        }
    });

    // SORT BY ALPHABET button handler
    
    actionbar.on(global.CONST.EVENT.SORTBYALPHABET, function() {
        if (exports.getCurrentScreen() === global.CONST.SCREEN.FAVORITES) {
            settings.setString(
                global.CONST.SCREEN.FAVORITES_SORTTYPE,
                global.CONST.BUTTON.SORTBYPOINT
            );
            actionbar.setLeftButton(global.CONST.BUTTON.SORTBYPOINT);
            favoritesScreen.refresh(actionbar.getLeftButton());
        }
    });

    // SETTINGS button handler

    actionbar.on(global.CONST.EVENT.SETTINGS, function() {
        controlbar.selectButton(global.CONST.BUTTON.SETTINGS);
    });

    // CONTROL button handler

    controlbar.on(global.CONST.EVENT.CONTROL, function(event) {
        exports.showScreen(event.id);
    });

    // Searching new provider

    favoritesScreen.on(global.CONST.EVENT.SEARCH, function(event) {
        controlbar.selectButton(global.CONST.SCREEN.SEARCH);
    });

    // Provider selected handler

    favoritesScreen.on(global.CONST.EVENT.PROVIDER, function(event) {
        settings.setString(
            global.CONST.SCREEN.SELECTEDPROVIDER,
            JSON.stringify(event.provider)
        );
        exports.showScreen(global.CONST.SCREEN.PROVIDER);
    });

    // Show provider info handler

    searchScreen.on(global.CONST.EVENT.SHOWPROVIDERINFO, function(event) {
        exports.showScreen(global.CONST.SCREEN.PROVIDERINFO, event.provider);
    });

    // Toggle provider subscribtion handler

    var toggleSubscribtion = function(event) {
        var provider = JSON.parse(event.provider);

        if (provider.selected) {
            if (!settings.getBoolean(global.CONST.SCREEN.UNSUBSCRIBE, false)) {
                container.showModal('./view/screen/dialog/dialog-page', event.provider, function closeCallback(result) {
                    if (result != global.CONST.EVENT.CANCEL) {
                        global.firebaseController.setValue({
                            path:   '/customers/' + settings.getString(global.CONST.USER.ID) + '/providers/' + provider.id,
                            value:  null
                        });

                        if (exports.getCurrentScreen() == global.CONST.SCREEN.SEARCH) {
                            searchScreen.refreshRegisterImage(provider.id, false);
                        } else if (exports.getCurrentScreen() == global.CONST.SCREEN.PROVIDERINFO) {
                            providerinfoScreen.refreshRegisterImage(false);
                        } else if (exports.getCurrentScreen() == global.CONST.SCREEN.MAP) {
                            mapScreen.refreshRegisterImage(false);
                        }
                    }
                }, true);
            }
        } else {
            global.firebaseController.setValue({
                path:   '/customers/' + settings.getString(global.CONST.USER.ID) + '/providers/' + provider.id,
                value:  true
            });

            if (exports.getCurrentScreen() == global.CONST.SCREEN.SEARCH) {
                searchScreen.refreshRegisterImage(provider.id, true);
            } else if (exports.getCurrentScreen() == global.CONST.SCREEN.PROVIDERINFO) {
                providerinfoScreen.refreshRegisterImage(true);
            } else if (exports.getCurrentScreen() == global.CONST.SCREEN.MAP) {
                mapScreen.refreshRegisterImage(true);
            }
        }
    };

    searchScreen.on(global.CONST.EVENT.SUBSCRIBE, function(event) {
        toggleSubscribtion(event);
    });

    mapScreen.on(global.CONST.EVENT.SUBSCRIBE, function(event) {
        toggleSubscribtion(event);
    });

    providerinfoScreen.on(global.CONST.EVENT.SUBSCRIBE, function(event) {
        toggleSubscribtion(event);
    });

    searchScreen.on(global.CONST.EVENT.UNSUBSCRIBE, function(event) {
        toggleSubscribtion(event);
    });

    mapScreen.on(global.CONST.EVENT.UNSUBSCRIBE, function(event) {
        toggleSubscribtion(event);
    });

    providerinfoScreen.on(global.CONST.EVENT.UNSUBSCRIBE, function(event) {
        toggleSubscribtion(event);
    });

    // Shows the provider info

    mapScreen.on(global.CONST.EVENT.SHOWPROVIDERINFO, function(event) {
        exports.showScreen(global.CONST.SCREEN.PROVIDERINFO, event.provider);
    });

    // Select a store
    
    var selectStore = function(event, screen) {
        if (!settings.getBoolean(global.CONST.SCREEN.STORESELECTOR, false)) {
            container.showModal('./view/screen/storeselector/storeselector-page', JSON.stringify(event.store), function closeCallback(result) {
                if (result && result != global.CONST.EVENT.CANCEL) {
                    screen.setStore(JSON.parse(result));
                }
            }, true);
        }
    };

    providerinfoScreen.on(global.CONST.EVENT.SELECTSTORE, function(event) {
        selectStore(event, providerinfoScreen);
    });
    
    providerScreen.on(global.CONST.EVENT.SELECTSTORE, function(event) {
        selectStore(event, providerScreen);
    });

    // Show filter handler
    
    searchScreen.on(global.CONST.EVENT.SHOWFILTER, function(event) {

        // Setting actionbar title based on the selected filter type

        actionbar.setTitle(global.locale.screen.filter.title[event.filterby]);
        
        // Showing the fiilter screen

        filterScreen.filterby = event.filterby;
        filterScreen.items = event.items;
        exports.showScreen(global.CONST.SCREEN.FILTER);
    });

    // Born date setting handler
    
    settingsScreen.on(global.CONST.EVENT.SETBORNDATE, function(event) {

        // Showing the date picker dialog

        if (!settings.getBoolean(global.CONST.SCREEN.BORNDATE, false)) {
            container.showModal('./view/screen/datepicker/datepicker-page', '', function closeCallback(result) {

                // Storing the born date

                if (result && result != global.CONST.EVENT.CANCEL) {
                    global.firebaseController.setValue({
                        path:   '/customers/' + settings.getString(global.CONST.USER.ID) + '/birthday',
                        value:  new Date(
                            parseInt(result.substring(0, 4)),
                            parseInt(result.substring(5, 7)) - 1,
                            parseInt(result.substring(8))
                        ).getTime()
                    });

                    settingsScreen.refreshBornDate();
                }
            }, true);
        }
    });
    
    // Registering the BACK button handler if the current platform is android

    if (application.android) {
        application.android.on(
            application.AndroidApplication.activityBackPressedEvent,
            backEvent
        );
    }

    // Initializing the Firebase if it is not initialized yet

    global.firebaseController.init().then(function() {

        // Initializing the Push Notification System
        
        global.firebaseController.initFCM();

        // Loading badges and storing these locally

        global.DB.loadBadges().then(function(badges) {
            settings.setString(
                global.CONST.LOCALDATA.BADGES, JSON.stringify(badges)
            );

            // Getting the current GPS position

            providerScreen.currentLocation = null;
            searchScreen.currentLocation = null;
            
            Geolocation.getCurrentLocation({
                desiredAccuracy:    enums.Accuracy.high, 
                updateDistance:     0, 
                maximumAge:         60000, 
                timeout:            30000
            }).then(function(location) {
                providerScreen.currentLocation = location;
                searchScreen.currentLocation = location;
            }).catch(function(response){
                // Location can not be determined
            });
        });;
    });

    // Setting test data

    global.db.provider = [
        { name: 'Elso', providerPicture: 'res://logo', actual: 3, total: 10, position: { lat: 47.479754, long: 19.051031 } },
        { name: 'Második', providerPicture: 'res://logo', actual: 6, total: 10, position: { lat: 47.478871, long: 19.049394 } },
        { name: 'Harmadik', providerPicture: 'res://logo', actual: 1, total: 10, position: { lat: 46.946908, long: 16.284997 } }
    ];

    global.db.filter = {
        category: [
            { id: '1', name: 'Elso' },
            { id: '2', name: 'Masodik' },
            { id: '3', name: 'Harmadik' },
            { id: '11', name: 'Elso1' },
            { id: '22', name: 'Masodik2' },
            { id: '33', name: 'Harmadik3' },
            { id: '44', name: 'Elso18' },
            { id: '55', name: 'Masodik28' },
            { id: '66', name: 'Harmadik38' },
            { id: '77', name: 'Elso11' },
            { id: '88', name: 'Masodik42' },
            { id: '16', name: 'Harmadik34' },
            { id: '14', name: 'Elso13' },
            { id: '15', name: 'Masodik23' },
            { id: '17', name: 'Harmadik33' },
            { id: '141', name: 'Elso131' },
            { id: '151', name: 'Masodik231' },
            { id: '171', name: 'Harmadik331' },
            { id: '1411', name: 'Elso1314' },
            { id: '1511', name: 'Masodik2314' },
            { id: '1711', name: 'Harmadik3314' },
            { id: '14118', name: 'Elso13148' },
            { id: '15118', name: 'Masodik23148' },
            { id: '17118', name: 'Harmadik33148' }
        ],
        district: [
            { id: '1', name: 'DistrictElso' },
            { id: '2', name: 'DistrictMasodik' },
            { id: '3', name: 'DistrictHarmadik' },
            { id: '11', name: 'DistrictElso1' },
            { id: '22', name: 'DistrictMasodik2' },
            { id: '33', name: 'DistrictHarmadik3' },
            { id: '44', name: 'DistrictElso18' },
            { id: '55', name: 'DistrictMasodik28' },
            { id: '66', name: 'DistrictHarmadik38' },
            { id: '77', name: 'DistrictElso11' },
            { id: '88', name: 'DistrictMasodik42' },
            { id: '16', name: 'DistrictHarmadik34' },
            { id: '14', name: 'DistrictElso13' },
            { id: '15', name: 'DistrictMasodik23' },
            { id: '17', name: 'DistrictHarmadik33' },
            { id: '141', name: 'DistrictElso131' },
            { id: '151', name: 'DistrictMasodik231' },
            { id: '171', name: 'DistrictHarmadik331' },
            { id: '1411', name: 'DistrictElso1314' },
            { id: '1511', name: 'DistrictMasodik2314' },
            { id: '1711', name: 'DistrictHarmadik3314' },
            { id: '14118', name: 'DistrictElso13148' },
            { id: '15118', name: 'DistrictMasodik23148' },
            { id: '17118', name: 'DistrictHarmadik33148' }            
        ],
        keyword: [
            { id: '1', name: 'KeywordElso' },
            { id: '2', name: 'KeywordMasodik' },
            { id: '3', name: 'KeywordHarmadik' },
            { id: '11', name: 'KeywordElso1' },
            { id: '22', name: 'KeywordMasodik2' },
            { id: '33', name: 'KeywordHarmadik3' },
            { id: '44', name: 'KeywordElso18' },
            { id: '55', name: 'KeywordMasodik28' },
            { id: '66', name: 'KeywordHarmadik38' },
            { id: '77', name: 'KeywordElso11' },
            { id: '88', name: 'KeywordMasodik42' },
            { id: '16', name: 'KeywordHarmadik34' },
            { id: '14', name: 'KeywordElso13' },
            { id: '15', name: 'KeywordMasodik23' },
            { id: '17', name: 'KeywordHarmadik33' },
            { id: '141', name: 'KeywordElso131' },
            { id: '151', name: 'KeywordMasodik231' },
            { id: '171', name: 'KeywordHarmadik331' },
            { id: '1411', name: 'KeywordElso1314' },
            { id: '1511', name: 'KeywordMasodik2314' },
            { id: '1711', name: 'KeywordHarmadik3314' },
            { id: '14118', name: 'KeywordElso13148' },
            { id: '15118', name: 'KeywordMasodik23148' },
            { id: '17118', name: 'KeywordHarmadik33148' }
        ]
    };

    // Showing the current screen

    controlbar.selectButton(exports.getCurrentScreen());
};

/**
 * Event that fires when the main page has been unloaded.
 * 
 * @param   {Object} event      event object
 */

exports.onUnloaded = function(event) {

    // Removing the registered handlers

    actionbar.off(global.CONST.EVENT.BACK);
    actionbar.off(global.CONST.EVENT.SORTBYPOINT);
    actionbar.off(global.CONST.EVENT.SORTBYALPHABET);
    actionbar.off(global.CONST.EVENT.SETTINGS);
    controlbar.off(global.CONST.EVENT.CONTROL);

    // Removing Firebase database listeners

    //global.firebaseController.removeDBListeners();

    // Removing the BACK button handler if the current platform is android

    if (application.android) {
        application.android.off(
            application.AndroidApplication.activityBackPressedEvent,
            backEvent
        );
    }
};

/**
 * Shows the speccified screen by screen ID.
 * 
 * @param   {Object} id         ID of the screen
 * @param   {Object} data       extra data
 */

exports.showScreen = function(id, data) {

    // Getting the requested screen

    var scr = container.getViewById(id + '_screen');
    scr.data = data;
    var currentScreen = exports.getCurrentScreen();

    if (currentScreen === id && scr.visibility != 'collapse') {
        return;
    }

    // Does any screen visible now? If yes then fade out this screen.

    if (currentScreen) {
        var cscr = container.getViewById(currentScreen + '_screen');

        if (cscr.visibility != 'collapse') {
            cscr.animate({
                opacity:    0,    
                curve:      enums.AnimationCurve.easeOut,
                duration:   global.CONST.SCREEN.FADING_INTERVAL
            }).then(function() {
                cscr.visibility = 'collapse';
            });
        }
    }

    // Hide the actionbar if it is requested

    if (scr.hideActionbar) {
        actionbar.visibility = 'collapse';
    } else {

        // Showing the actionbar

        actionbar.visibility = 'visible';

        // Setting the back button on the actionbar

        actionbar.setLeftButton(scr.leftButton);
        
        // Setting the settings button on the actionbar

        actionbar.setSettingsButton(
            scr.showSettings ? (id === global.CONST.SCREEN.SETTINGS) : undefined
        );

        // Setting the title of the screen

        if (scr.title) {
            actionbar.setTitle(scr.title);
        }
    }

    // Showing the requested screen with opacity 0

    scr.visibility = 'visible';

    // Firing the "onOpen" event if it is handled by the requested screen
    
    if (scr.onOpen) {
        scr.onOpen( { 
            leftButton: actionbar.getLeftButton() 
        });
    }

    // Fade in the requested screen

    scr.animate({
        opacity:    1,    
        curve: enums.AnimationCurve.easeOut,
        duration:   global.CONST.SCREEN.FADING_INTERVAL
    });
    
    // Registering the previous and the current screen
    
    exports.previousScreen = currentScreen;
    settings.setString(global.CONST.SCREEN.CURRENTSCREEN, id);

    if (exports.previousScreen) {
        settings.setString(global.CONST.SCREEN.PREVIOUSSCREEN, exports.previousScreen);
    }
};

/**
 * Gets the current screen.
 * 
 * @return  {String}    screen  id of the current screen
 */

exports.getCurrentScreen = function() {
    return settings.getString(global.CONST.SCREEN.CURRENTSCREEN);
};
