'use strict';

/*
Copyright (C) 2017 Andras Sarvari <andras.sarvari@sarvaria.net>

Permission to use, copy, modify, and/or distribute this software for any
purpose with or without fee is hereby granted, provided that the above
copyright notice and this permission notice appear in all copies.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
*/

// Loading required modules

var application = require('application');
var settings = require('application-settings');
var frameModule = require('ui/frame');
var enums = require('ui/enums');
var Observable = require('data/observable').Observable;
var ProviderController = require('../../../controller/provider.js').ProviderController;

// Declaring module level constanses

const SHOW_LOGIN = 'login';
const SHOW_PROGRESS = 'progress';

// Declaring module level variables

var container;
var loginlabel1;
var loginlabel2;
var loginlabel3;
var loginlabel4;
var loginlabel5;
var loginlabel6;
var usernameContainer;
var buttonContainer;
var button;
var progress;

/**
 * Event that fires when the screen has been loaded.
 * 
 * @param   event       event object
 */

exports.onLoaded = function(event) {

    // Setting foreground color of the statusbar on android devices

    if (application.android) {
        application.android.startActivity.getWindow().getDecorView()
        .setSystemUiVisibility(
            android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        );
    }
    
    // Initializing

    container = event.object;
    loginlabel1 = container.getViewById('loginlabel1');
    loginlabel2 = container.getViewById('loginlabel2');
    loginlabel3 = container.getViewById('loginlabel3');
    loginlabel4 = container.getViewById('loginlabel4');
    loginlabel5 = container.getViewById('loginlabel5');
    loginlabel6 = container.getViewById('loginlabel6');
    buttonContainer = container.getViewById('buttoncontainer');
    usernameContainer = container.getViewById('usernamecontainer');
    button = container.getViewById('button');
    progress = container.getViewById('progress');

    // Localizing
    
    loginlabel1.text = global.locale.screen.login.label1;
    loginlabel2.text = global.locale.screen.login.label2;
    loginlabel3.text = global.locale.screen.login.label3;
    loginlabel4.text = global.locale.screen.login.label4;
    loginlabel5.text = global.locale.screen.login.label5;
    loginlabel6.text = global.locale.screen.login.label6;
    button.text = global.locale.screen.login.button;
    
    // Setting default value and bindig of the username

    var model = new Observable();
    model.set('username', '');
    container.bindingContext = model;
    
    // Showing the login

    exports.showScreen(SHOW_LOGIN);
};

/**
 * Downloads the pictures of the providers.
 */

exports.providerPictureDownload = function() {

    // Downloading provider pictures

    return new ProviderController().savePuzzlePicture();
};

/**
 * Shows the main screen by using animation.
 */

exports.showMainScreen = function() {

    // Setting the default screen

    settings.remove(global.CONST.SCREEN.PREVIOUSSCREEN);
    settings.setString(
        global.CONST.SCREEN.CURRENTSCREEN,
        global.CONST.SCREEN.FAVORITES
    )

    // Navigating to the main screen

    frameModule.topmost().navigate({
        moduleName:     'main-page',
        animated:       true,
        transition: {
            name:       'flip',
            duration:   600,
            curve:      'easeIn'
        }
    });
};

/**
 * Handles the login failed event.
 * 
 * @param   error {String}  error message
 */

exports.handleError = function(error) {

    // Showing the error message

    alert(error || global.locale.message.error);
    
    // Showing the login providers

    exports.showScreen(SHOW_LOGIN);
};

/**
 * Shows the requested screen state.
 * 
 * @param   state {String}      screen state
 */

exports.showScreen = function(state) {

    // Showing the screen state

    if (state == SHOW_LOGIN) {
        loginlabel1.visibility = 'visible';
        loginlabel2.visibility = 'visible';
        loginlabel3.visibility = 'visible';
        loginlabel4.visibility = 'visible';
        loginlabel5.visibility = 'visible';
        loginlabel6.visibility = 'visible';
        usernameContainer.visibility = 'visible';
        buttonContainer.visibility = 'visible';
        progress.visibility = 'collapse';
    } else if (state == SHOW_PROGRESS) {
        loginlabel1.visibility = 'collapse';
        loginlabel2.visibility = 'collapse';
        loginlabel3.visibility = 'collapse';
        loginlabel4.visibility = 'collapse';
        loginlabel5.visibility = 'collapse';
        loginlabel6.visibility = 'collapse';
        usernameContainer.visibility = 'collapse';
        buttonContainer.visibility = 'collapse';
        progress.visibility = 'visible';

        // Rotating the progress indicator

        progress.rotate = 0;
        progress.animate({
            rotate:         360,
            duration:       1200,
            iterations:     0,
            curve:          'linear'
        });            
    }
};

/**
 * Event that fire when the user taps the login button.
 */

exports.login = function() {

    // Validating username

    var name = container.bindingContext.get('username');

    if (name.length < 4 || name.indexOf(' ') >= 0) {
        alert(global.locale.screen.login.usernamerule);
        return;
    }

    // Registering the user

    settings.setString(global.CONST.USER.NAME, name);

    // Showing progress indicator

    exports.showScreen(SHOW_PROGRESS);
    
    // Initializing the Firebase

    global.firebaseController.init().then(function() {

        // Logging in by using ANONYMOUS authentication provider

        global.firebaseController.login(
            global.firebaseController.getFirebase().LoginType.ANONYMOUS,
            name
        ).then(function(user) {

            // Initializing the Push Notification System

            global.firebaseController.initFCM();

            // Downloading provider pictures

            exports.providerPictureDownload();
            
            // Showing the main screen

            exports.showMainScreen();
        }, function(error) {

            // Login failed

            exports.handleError(error);
        });                
    }, function(error) {

        // Firebase initialization failed

        exports.handleError(error);
    });
};
