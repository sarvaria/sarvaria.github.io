'use strict';

/*
Copyright (C) 2017 Andras Sarvari <andras.sarvari@sarvaria.net>

Permission to use, copy, modify, and/or distribute this software for any
purpose with or without fee is hereby granted, provided that the above
copyright notice and this permission notice appear in all copies.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
*/

// Loading required modules

var settings = require('application-settings');
var Geolocation = require('nativescript-geolocation');
var gestures = require('ui/gestures');
var enums = require('ui/enums');
var layout = require('ui/layouts/stack-layout');
var gridlayout = require('ui/layouts/grid-layout');
var imageModule = require('ui/image');
var labelModule = require('ui/label');
var Observable = require('data/observable').Observable;

// Declaring module level variables

var container;
var districtLabel;
var keywordLabel;
var clearDistrictsButton;
var clearKeywordsButton;
var providerContainer;
var searchBox;
var searchboxIcon;
var swipedItems;
var providers;
var keywords;
var locations;

/**
 * Event that fires when the screen has been loaded.
 * 
 * @param   event       event object
 */

exports.onLoaded = function(event) {

    // Initializing

    container = event.object;
    container.onOpen = exports.onOpen;
    container.refreshRegisterImage = exports.refreshRegisterImage;
    container.showSettings = true;
    container.title = global.locale.screen.search.title;

    // Getting the components

    districtLabel = container.getViewById('district');
    keywordLabel = container.getViewById('keyword');
    clearDistrictsButton = container.getViewById('cleardistricts');
    clearKeywordsButton = container.getViewById('clearkeywords');
    providerContainer = container.getViewById('providercontainer');
    searchBox = container.getViewById('search_textinput');
    searchboxIcon = container.getViewById('searchboxicon');

    // Holder of the swiped items

    swipedItems = [];
    
    // Keypress event handler of the searchbox

    var model = new Observable();
    model.set('search', '');

    model.addEventListener(Observable.propertyChangeEvent, function(event) {

        // Closing the current slided providder item

        exports.closeSlidedItems(false, true);

        // Showing the clear or search icon based on the value of the searchbox.
        // It shows the clear icon if the searchbox is not empty and search
        // icon if this box is empty.

        if (event.value && event.value != '') {
            searchboxIcon.src = 'res://clear';
        } else {
            searchboxIcon.src = 'res://searchbox';
        }

        exports.filter();
    });

    container.bindingContext = model;
};

/**
 * Event that fires when the screen opened.
 */

exports.onOpen = function() {

    // Aligning the layout of the searchbox and the filter buttons

    searchBox.width = (global.screenSize.widthDP - 86) + 'dp';
    districtLabel.width = (global.screenSize.widthDP - 96) + 'dp';
    keywordLabel.width = districtLabel.width;

    // Closing all of the slided provider items

    exports.closeSlidedItems(true);
    
    // Loading all of the keywords

    global.DB.loadKeywords().then(function(items) {
        keywords = items;

        // Loading all of the locations

        global.DB.loadDistricts().then(function(items) {
            locations = items;

            // Setting the district filter

            exports.setSelection(
                'district',
                districtLabel,
                clearDistrictsButton,
                global.locale.screen.search.alldistricts
            );

            // Setting the keyword filter

            exports.setSelection(
                'keyword',
                keywordLabel,
                clearKeywordsButton,
                global.locale.screen.search.allkeywords
            );
            
            // Refreshing the provider list based on the filter criteria

            if (!container.currentLocation) {
                Geolocation.getCurrentLocation({
                    desiredAccuracy:    enums.Accuracy.high, 
                    updateDistance:     0, 
                    maximumAge:         60000, 
                    timeout:            30000
                }).then(function(location) {
                    container.currentLocation = location;
                    exports.refresh();
                });
            } else {
                exports.refresh();
            }
        });
    });    
};

/**
 * Event that fires when the register button on a provider item tapped.
 * 
 * @param   {String}    provider    selected provider
 */

exports.toggleRegister = function(provider) {

    // Closing the slided provider item

    exports.closeSlidedItems();

    // Firing the SUBSCRIBE/UNSUBSCRIBE event for the selected provider

    container.notify({
        eventName:  provider.selected ? global.CONST.EVENT.UNSUBSCRIBE : 
                                        global.CONST.EVENT.SUBSCRIBE,
        provider:   provider
    });
};

/**
 * Event that fires when the info button on a provider item tapped.
 * 
 * @param   {Object}    provider    selected provider
 */

exports.showProviderInfo = function(provider) {

    // Closing the slided provider item

    exports.closeSlidedItems();

    // Firing the SHOWPROVIDERINFO event for the selected provider

    container.notify({
        eventName:  global.CONST.EVENT.SHOWPROVIDERINFO,
        provider:   provider
    });
};

/**
 * Event that fires when the district fiter button tapped.
 */

exports.showDistrictFilter = function() {

    // Closing the slided provider item

    exports.closeSlidedItems();

    // Firing the SHOWFILTER event for the district filter

    container.notify({
        eventName:  global.CONST.EVENT.SHOWFILTER,
        filterby:   'district',
        items:      locations
    });
};

/**
 * Event that fires when the keyword fiter button tapped.
 */

exports.showKeywordFilter = function() {

    // Closing the slided provider item

    exports.closeSlidedItems();

    // Firing the SHOWFILTER event for the keyword filter

    container.notify({
        eventName:  global.CONST.EVENT.SHOWFILTER,
        filterby:   'keyword',
        items:      keywords
    });
};

/**
 * Event that fires when the clear filter button tapped.
 * 
 * @param   {String}    filtertype  type of the filter
 */

exports.clearFilterItems = function(filtertype) {

    // Observing the filter items for the specified filter type

    var items = filtertype == 'keyword' ? keywords : locations;

    for (var i = 0; i < items.length; i++) {

        // Getting the filter item key for the specified filter type

        var key = 'filter_' + filtertype + '___' + items[i].id;
    
        // Removing the selection of the filter item if it was selected

        if (settings.getBoolean(key)) {
            settings.remove(key);
        }
    }

    // Closing the slided provider item
    
    exports.closeSlidedItems();
};

/**
 * Sets the selected filter items on the filter buttons based on the specified
 * filter type. If there were no selection the all items text will be appear.
 * 
 * @param   {String}    filtertype      type of the filter
 * @param   {Object}    labelElement    element for the filter label
 * @param   {Object}    buttonElement   element for the filter button
 * @param   {String}    allItems        all items text
 */

 exports.setSelection = function(filtertype, labelElement, buttonElement, allItems) {

    // Preparing

    var label = '';
    
    // Observing the filter items for the specified filter type

    var items = filtertype == 'keyword' ? keywords : locations;

    for (var i = 0; i < items.length; i++) {

        // Getting the filter item key for the specified filter type

        var key = 'filter_' + filtertype + '___' + items[i].id;

        // Setting the label of the filter it the filter item was selected

        if (settings.getBoolean(key)) {
            label += items[i].name + ', ';
        }

        // Showing the filter button based on the content of the label

        buttonElement.visibility = label !== '' ? 'visible' : 'collapse';
        
        // Setting the filter label

        labelElement.text = label !== '' ? label.substring(0, label.length - 2) : allItems;
    }
};

/**
 * Clears all of the selected districts.
 */

exports.clearDistrits = function() {

    // Setting the filter type

    var filtertype = 'district';
    
    // Clearing the filter items

    exports.clearFilterItems(filtertype);
    
    // Refreshing the filter button for the district filter

    exports.setSelection(
        filtertype,
        districtLabel,
        clearDistrictsButton,
        global.locale.screen.search.alldistricts
    );
};

/**
 * Clears all of the selected keywords.
 */

exports.clearKeywords = function() {

    // Setting the filter type
    
    var filtertype = 'keyword';

    // Clearing the filter items

    exports.clearFilterItems(filtertype);

    // Refreshing the filter button for the keyword filter

    exports.setSelection(
        filtertype,
        keywordLabel,
        clearKeywordsButton,
        global.locale.screen.search.allkeywords
    );
};

/**
 * Clears all of the selected keywords.
 */

exports.refresh = function() {

    // Getting all of the providers from Firebase DB

    global.DB.loadProviders().then(function(items) {
        console.dir(items);
        providers = items;

        // Refreshing the provider items based on the filter criteria

        exports.filter();
    });
};

exports.refreshRegisterImage = function(id, selected) {
    for (var i = 0; i < providers.length; i++) {
        if (providers[i].id == id) {
            providers[i].selected = selected;
            break;
        }
    }

    container.getViewById('registerimage___' + id).src = 
    selected ? 'res://favorite_highlight' : 'res://favorites_unselected';
};

/**
 * Cleaars the content of the searchbox.
 */

exports.clearSearchContent = function() {

    // Clearing the content of the searchbox

    container.bindingContext.set('search', '');

    // Closing the slided provider item
       
    exports.closeSlidedItems();
};

/**
 * Closes the slided items. It uses animation during the slide out if it is
 * requested and closes the soft keyboard as well.
 * 
 * @param   {Boolean}   skipAnimation   skip animation during the slide out
 *                                      (optional). Default is false.
 * @param   {Boolean}   skipKeyboard    closes the soft keyborad
 *                                      (optional). Default is false.
 */

exports.closeSlidedItems = function(skipAnimation, skipKeyboard) {

    // Closes the soft keyborad

    if (!skipKeyboard) {
        searchBox.dismissSoftInput();
    }

    // Getting the swiped items

    for (var i = 0; i < swipedItems.length; i++) {

        // Getting the provider item body and register button

        var itemBody = container.getViewById('searchbody___' + swipedItems[i]);
        var registerHolder = container.getViewById('searchregisterholder___' + swipedItems[i]);

        // Swipe out the item

        if (skipAnimation) {
            itemBody.translateX = 0;
            registerHolder.translateX = 0;
        } else {
            itemBody.swiping = true;
        
            itemBody.animate({
                translate: { x: 0, y: 0 },
                curve: enums.AnimationCurve.easeOut,
                duration:   160
            }).then(function() {
                itemBody.swiping = false;
            });
        
            registerHolder.animate({
                translate: { x: 0, y: 0 },
                curve: enums.AnimationCurve.easeOut,
                duration:   160
            });
        }

        // Registering the swipe state of the provider item

        itemBody.swiped = !itemBody.swiped;
    }

    // Clearing the holder of the swiped items
    
    swipedItems = [];
};

// Creating the provider item

exports.createItem = function(provider) {
    
    // Declaring a new provider item

    var item = new layout.StackLayout();
    item.className = 'search_provider_item';

    var relativeLayout = new gridlayout.GridLayout();
    relativeLayout.height = '72dp';

    var imageHolder = new layout.StackLayout();
    imageHolder.id = 'imageholder___' + provider.id;
    imageHolder.height = relativeLayout.height;
    imageHolder.className = 'search_provider_infobutton';
    imageHolder.orientation = 'vertical';
    imageHolder.verticalAlignment = 'center';
    
    // Creating the info button

    var infoButton = new imageModule.Image();
    infoButton.src = 'res://info';
    infoButton.width = '24dp';
    infoButton.height = infoButton.width;
    infoButton.horizontalAlignment = 'right';
    imageHolder.addChild(infoButton);
    
    imageHolder.on('tap', function(event) {
        var id = event.object.id.split('___')[1];
        
        for (var i = 0; i < providers.length; i++) {
            if (providers[i].id == id) {
                exports.showProviderInfo(providers[i]);
                break;
            }
        }
    });
    
    relativeLayout.addChild(imageHolder);
    
    // Create provider item body

    var itemBody = new layout.StackLayout();
    itemBody.id = 'searchbody___' + provider.id;
    itemBody.className = 'search_provider_container';
    itemBody.orientation = 'horizontal';
    itemBody.verticalAlignment = 'center';
    itemBody.width = '100%';
    itemBody.height = relativeLayout.height;

    // Tap event for provider item body

    itemBody.on('tap', function(event) {
        var id = event.object.id.split('___')[1];
        
        for (var i = 0; i < providers.length; i++) {
            if (providers[i].id == id) {
                exports.showProviderInfo(providers[i]);
                break;
            }
        }
    });
    
    // Swipe event for provider item

    itemBody.on(gestures.GestureTypes.pan, function(event) {
        if (!itemBody.swiping && Math.abs(event.deltaX) >= global.CONST.SCREEN.SWIPE_SENSITIVITY && (event.deltaX < 0 || event.deltaX > 0) && !((itemBody.swiped && event.deltaX < 0) || (!itemBody.swiped && event.deltaX > 0))) {
            if (!itemBody.swiped) {
                exports.closeSlidedItems();
            }

            itemBody.swiping = true;
            itemBody.animate({
                translate: { x: !itemBody.swiped && event.deltaX < 0 ? -72 : 0, y: 0 },
                curve: enums.AnimationCurve.easeOut,
                duration:   160
            }).then(function() {
                itemBody.swiping = false;
            });
            registerHolder.animate({
                translate: { x: !itemBody.swiped && event.deltaX < 0 ? -72 : 0, y: 0 },
                curve: enums.AnimationCurve.easeOut,
                duration:   160
            });
            itemBody.swiped = !itemBody.swiped;

            var ind = itemBody.id.split('___')[1];

            if (itemBody.swiped) {
                swipedItems.push(ind);
            } else {
                for (var j = 0; j < swipedItems.length; j++) {
                    if (swipedItems[j] == ind) {
                        swipedItems.splice(j, 1);
                    }
                }
            }
        }
    });

    // Creating the provider picture
    
    var providerPicture = new imageModule.Image();
    providerPicture.src = 'res://icon';
    providerPicture.className = 'search_provider_image';
    providerPicture.width = '48dp';
    providerPicture.height = providerPicture.width;
    itemBody.addChild(providerPicture);

    // Creating the provider info

    var itemInfo = new layout.StackLayout();
    itemInfo.className = 'search_provider_info';
    itemInfo.orientation = 'vertical';
    itemInfo.verticalAlignment = 'center';

    var providerName = new labelModule.Label();
    providerName.className = 'search_provider_name font_regular';
    providerName.text = provider.name;
    itemInfo.addChild(providerName);
    
    var openInfo = new layout.StackLayout();
    openInfo.orientation = 'horizontal';

    var loc = new labelModule.Label();
    loc.class = 'search_provider_hours font_bold';
    loc.text = 'nearest location:';
    openInfo.addChild(loc);
    
    var dist = 100000000;

    for (var i = 0; i < provider.store.length; i++) {
        var gps = provider.store[i].gps.split(',');
        var loc = new Geolocation.Location();
        loc.longitude = parseFloat(gps[0].trim());
        loc.latitude = parseFloat(gps[1].trim());
        var d = Geolocation.distance(container.currentLocation, loc);

        if (d < dist) {
            dist = parseInt(d);
        }
    }

    var measurement;

    if (dist < 1000) {
        measurement = 'm';
    } else {
        measurement = 'km';
        dist = parseInt(dist / 1000);
    }
    
    var distance = new labelModule.Label();
    distance.class = 'search_provider_distance font_bold';
    distance.text = dist + ' ' + measurement;
    openInfo.addChild(distance);
    
    var distanceMeasurement = new labelModule.Label();
    distanceMeasurement.class = 'search_provider_distancemeasurement font_regular';
    distanceMeasurement.text = ' away';
    openInfo.addChild(distanceMeasurement);
    
    itemInfo.addChild(openInfo);

    itemBody.addChild(itemInfo);

    relativeLayout.addChild(itemBody);
    
    var registerHolder = new layout.StackLayout();
    registerHolder.id = 'searchregisterholder___' + provider.id;
    registerHolder.height = relativeLayout.height;
    registerHolder.className = 'search_provider_registerbutton';
    registerHolder.orientation = 'vertical';
    registerHolder.verticalAlignment = 'center';

    var registerImage = new imageModule.Image();
    registerImage.id = 'registerimage___' + provider.id;
    registerImage.src = (provider.selected ? 'res://favorite_highlight' : 'res://favorites_unselected');
    registerImage.width = '32dp';
    registerImage.height = registerImage.width;
    registerImage.horizontalAlignment = 'right';
    
    // Tap event for the register button of the provider item

    registerImage.on('tap', function(event) {
        var id = event.object.id.split('___')[1];

        for (var i = 0; i < providers.length; i++) {
            if (providers[i].id == id) {
                exports.toggleRegister(JSON.stringify(providers[i]));
                break;
            }
        }                
    });

    registerHolder.addChild(registerImage);
    
    relativeLayout.addChild(registerHolder);
    
    item.addChild(relativeLayout);

    // Returns the provider item

    return item;
};

exports.filter = function() {

    // Clearing provider list

    providerContainer.removeChildren();
    
    var name = container.bindingContext.get('search');

    var match = function(name, providername, stores) {

        // Filter by name

        var charsFrom = 'öüóőúéáűí';
        var charsTo = 'ouooueaui';

        var pn = providername.toLowerCase();
        var n = name.toLowerCase();
        
        for (var i = 0; i < charsFrom.length; i++) {
            pn = pn.replace(charsFrom[i], charsTo[i]);
            n = n.replace(charsFrom[i], charsTo[i]);
        }

        var pass = pn.indexOf(name) >= 0;
        
        // Filter by keywords

        var isChecked = false;

        for (var i = 0; i < keywords.length; i++) {
            if (settings.getBoolean('filter_keyword___' + keywords[i].id)) {
                isChecked = true;
                break;
            }
        }

        if (pass && isChecked) {
            var found = false;
            
            for (var i = 0; i < stores.length; i++) {
                var ks = stores[i].keywords[global.locale.language];

                for (var key in ks) {
                    if (ks.hasOwnProperty(key)) {
                        if (settings.getBoolean('filter_keyword___' + key)) {
                            found = true;
                            break;
                        }
                    }
                }

                if (found) {
                    break;
                }
            }

            pass = found;
        }
        
        // Filter by locations
        
        isChecked = false;
        
        for (var i = 0; i < locations.length; i++) {
            if (settings.getBoolean('filter_district___' + locations[i].id)) {
                isChecked = true;
                break;
            }
        }

        if (pass && isChecked) {
            var found = false;
            
            for (var i = 0; i < stores.length; i++) {
                if (settings.getBoolean('filter_district___' + stores[i].location)) {
                    found = true;
                    break;
                }
            }

            pass = found;                            
        }

        // Returns the result

        return pass;
    };

    // Filtering the providers

    for (var i = 0; i < providers.length; i++) {
        if (match(name, providers[i].name, providers[i].store)) {
            providerContainer.addChild(exports.createItem(providers[i]));
        }
    }
};
