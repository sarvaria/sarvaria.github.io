/*
Copyright (C) 2017 Andras Sarvari <andras.sarvari@sarvaria.net>

Permission to use, copy, modify, and/or distribute this software for any
purpose with or without fee is hereby granted, provided that the above
copyright notice and this permission notice appear in all copies.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
*/

// Loading required modules

var settings = require('application-settings');
var Geolocation = require('nativescript-geolocation');
var enums = require('ui/enums');
var imageModule = require('ui/image');
var ProviderController = require('../../../controller/provider.js').ProviderController;

// Declaring module level variables

var container;
var providerPicture;
var providerName;
var chartFullLine;
var chartValueLine;
var freebie;
var actualpoint;
var totalpoint;
var totalpoints;
var badgeContainer;
var badgeTitle;
var badgeSubtitle
var puzzle;
var requestpointContainer;
var requestpointIcon;
var requestpointIconAnimated;
var requestpointLabel;
var storeName;
var pointState;

/**
 * Event that fires when the screen has been loaded.
 * 
 * @param   event       event object
 */

exports.onLoaded = function(event) {

    // Getting the container and propagating the public methods

    container = event.object;
    container.onOpen = exports.onOpen;
    container.setStore = exports.setStore;
    container.leftButton = 'back';
    container.showSettings = true;
    container.title = global.locale.screen.favorites.title;
    providerPicture = container.getViewById('providerpicture');
    providerName = container.getViewById('providername');
    freebie = container.getViewById('freebie');
    actualpoint = container.getViewById('actualpoint');
    totalpoint = container.getViewById('totalpoint');
    totalpoints = container.getViewById('totalpoints');
    chartFullLine = container.getViewById('chart_fullline');
    chartValueLine = container.getViewById('chart_valueline');
    badgeContainer = container.getViewById('badge_container');
    badgeTitle = container.getViewById('badgetitle');
    badgeSubtitle = container.getViewById('badgesubtitle');
    puzzle = container.getViewById('puzzle');
    requestpointContainer = container.getViewById('requestpointcontainer');
    requestpointIcon = container.getViewById('requestpointicon');
    requestpointIconAnimated = container.getViewById('requestpointiconanimated');
    requestpointLabel = container.getViewById('requestpointlabel');
    storeName = container.getViewById('storename');
    
    // Localize

    container.getViewById('freebielabel').text = global.locale.screen.provider.freebie;
    container.getViewById('puzzlelabel').text = global.locale.screen.provider.puzzle;
    container.getViewById('totalpointslabel').text = global.locale.screen.provider.total;

    requestpointIconAnimated.animate({
        rotate:         360,
        duration:       1200,
        iterations:     0,
        curve:          'linear'
    });        

    // Setting the state of the request point button

    exports.setRequestPointState(
        settings.getString(
            global.CONST.POINTREQUESTSTATE.STATE,
            global.CONST.POINTREQUESTSTATE.LOCATING
        )
    );
};

/**
 * Event that fires when the provider page has been unloaded.
 * 
 * @param   {Object} event      event object
 */

exports.onUnloaded = function(event) {
    exports.removeListeners();
    exports.removePointListener();
};

/**
 * Event that fires when the screen opened.
 */

exports.onOpen = function() {

    exports.removeListeners();
    exports.removePointListener();

    // Setting provider picture

    container.provider = JSON.parse(
        settings.getString(global.CONST.SCREEN.SELECTEDPROVIDER, '{}')
    );

    settings.remove(global.CONST.SCREEN.STORESELECTOR);
    providerPicture.src = container.provider.providerPicture;
    
    // Setting provider name

    providerName.text = container.provider.name;

    // Setting freebie, actual, prover and total points

    freebie.text = container.provider.freebieCount;
    actualpoint.text = container.provider.balance;
    totalpoint.text = '/' + container.provider.maxPoint;
    totalpoints.text = container.provider.totalPoints;

    // Setting badge title and subtitle

    var badges = JSON.parse(settings.getString(global.CONST.LOCALDATA.BADGES, '[]'));
    var badge = { title: '', subtitle: '' };
    var threshold = 0;
    var maxThreshold = 0;

    for (var i = 0; i < badges.length; i++) {
        if (badges[i].threshold > maxThreshold) {
            maxThreshold = badges[i].threshold;
        }

        if (badges[i].threshold <= container.provider.totalPoints && 
        badges[i].threshold > threshold) {
            threshold = badges[i].threshold;
            badge = badges[i][global.locale.language];
        }
    }

    badgeTitle.text = badge.title;
    badgeSubtitle.text = (badge.subtitle == '' ? ''  : ' | ') + badge.subtitle;
    
    // Setting total points chart

    var percent = parseInt((container.provider.totalPoints / maxThreshold) * 100);
    var size = global.screenSize.widthDP - 128;
    chartFullLine.width = size + 'dp';
    chartValueLine.width = parseInt(size * (percent / 100)) + 'dp';

    // Define badge icon renderer

    var createBadgeIcon = function(position) {
        var badge = new imageModule.Image();
        badge.src = 'res://badge0' + (parseInt(position / 33) + 1) + '_' +
                    (percent >= position ? 'selected' : 'unselected');
        badge.width = '24dp';
        badge.height = badge.width;
        badge.top = '0dp';
        badge.left = (20 + (size * (position / 100))) + 'dp';
        badgeContainer.addChild(badge);
    };

    // Adding badge icons to the chart

    createBadgeIcon(0);
    createBadgeIcon(33);
    createBadgeIcon(66);
    createBadgeIcon(100);

    // Setting the puzzle image

    var providerController = new ProviderController();
    providerController.loadPuzzlePicture().then(function(image) {
        puzzle.src = image;
    });

    exports.refreshPuzzle(container.provider.balance);

    // Setting puzzle size

    var availableHeight = global.screenSize.heightDP - (372 + 48 + 16 + 26);
    var availableWidth = global.screenSize.widthDP - 32 - 32;
    var size = Math.min(availableHeight, availableWidth);

    container.getViewById('puzzle').width = size + 'dp';
    container.getViewById('puzzle').height = container.getViewById('puzzle').width;

    container.getViewById('puzzle_watermark').width = container.getViewById('puzzle').width;
    container.getViewById('puzzle_watermark').height = container.getViewById('puzzle').height;
    container.getViewById('puzzle_container').height = container.getViewById('puzzle').height;

    global.firebaseController.getFirebase().addValueEventListener(function(result) {
        if (container.provider.balance != result.value.balance) {
            container.provider.balance = result.value.balance;
            exports.refreshPuzzle(container.provider.balance);
            exports.changeTotalPoints([ result.value.freebieCount, result.value.balance, result.value.totalPoints ]);
        }
    }, '/customers/' + settings.getString(global.CONST.USER.ID) + '/providers/' + container.provider.id).then(function(listenerWrapper) {
        container.pointlistener = { 
            listeners: listenerWrapper.listeners,
            path:      listenerWrapper.path
        };
    });

    if (container.currentLocation) {
        if (container.provider.store) {
            exports.setStore(exports.getNearestStore());
        } else {
            exports.setStore(container.provider.store[0]);
        }    
    } else {
        exports.getLocation().then(function(loc) {
            container.currentLocation = loc;

            // Setting the nearest store

            if (container.currentLocation && container.provider.store) {
                exports.setStore(exports.getNearestStore());
            } else {
                exports.setStore(container.provider.store[0]);
            }
        });
    }
};

exports.getNearestStore = function() {
    var distance = 1000000000;
    var store = null;

    if (container.provider && container.provider.store) {
        for (var i = 0; i < container.provider.store.length; i++) {
            var gps = container.provider.store[i].gps.split(',');
            var loc = new Geolocation.Location();
            loc.longitude = parseFloat(gps[0].trim());
            loc.latitude = parseFloat(gps[1].trim());
            var d = Geolocation.distance(container.currentLocation, loc);
            
            if (d < distance) {
                distance = d;
                store = container.provider.store[i];
            }
        }
    }

    return store;
};

exports.getDistance = function(store) {
    var gps = store.gps.split(',');
    var loc = new Geolocation.Location();
    loc.longitude = parseFloat(gps[0].trim());
    loc.latitude = parseFloat(gps[1].trim());
    
    if (Geolocation.distance(container.currentLocation, loc) <= 100) {
        exports.setRequestPointState(global.CONST.POINTREQUESTSTATE.INRANGE);    
    } else {
        exports.setRequestPointState(global.CONST.POINTREQUESTSTATE.OUTOFRANGE);    
    }
};

exports.getLocation = function() {
    return new Promise(function(resolve, reject) {

        // Setting the state of the request point button

        exports.setRequestPointState(global.CONST.POINTREQUESTSTATE.LOCATING);

        // Getting the current GPS position

        Geolocation.getCurrentLocation({
            desiredAccuracy:    enums.Accuracy.high, 
            updateDistance:     0, 
            maximumAge:         60000, 
            timeout:            30000
        }).then(function(location) {
            resolve(location);
        }).catch(function(response){
            
            // Error occured during GPS obtaining

            exports.setRequestPointState(global.CONST.POINTREQUESTSTATE.OUTOFRANGE);
            resolve();
        });        
    });
};

exports.setRequestPointState = function(state) {
    pointState = state;
    settings.setString(global.CONST.POINTREQUESTSTATE.STATE, state);

    if (state == global.CONST.POINTREQUESTSTATE.LOCATING) {
        requestpointContainer.className = 'provider_requestpoint provider_requestpoint_locating';
        requestpointIcon.visibility = 'collapse';
        requestpointIconAnimated.visibility = 'visible';
        requestpointLabel.text = global.locale.screen.provider.requestpointlabel.locating;
        requestpointLabel.className = 'provider_requestpoint_label provider_requestpoint_label_locating font_bold';
    } else if (state == global.CONST.POINTREQUESTSTATE.INRANGE) {
        requestpointContainer.className = 'provider_requestpoint provider_requestpoint_inrange';
        requestpointIcon.visibility = 'collapse';
        requestpointIconAnimated.visibility = 'collapse';
        requestpointLabel.text = global.locale.screen.provider.requestpointlabel.inrange;
        requestpointLabel.className = 'provider_requestpoint_label provider_requestpoint_label_inrange font_bold';
    } else if (state == global.CONST.POINTREQUESTSTATE.OUTOFRANGE) {
        requestpointContainer.className = 'provider_requestpoint provider_requestpoint_outofrange';
        requestpointIcon.visibility = 'visible';
        requestpointIconAnimated.visibility = 'collapse';
        requestpointLabel.text = global.locale.screen.provider.requestpointlabel.outofrange;
        requestpointLabel.className = 'provider_requestpoint_label provider_requestpoint_label_outofrange font_bold';
    } else if (state == global.CONST.POINTREQUESTSTATE.INPROGRESS) {
        requestpointContainer.className = 'provider_requestpoint provider_requestpoint_inprogress';
        requestpointIcon.visibility = 'collapse';
        requestpointIconAnimated.visibility = 'visible';
        requestpointLabel.text = global.locale.screen.provider.requestpointlabel.inprogress;
        requestpointLabel.className = 'provider_requestpoint_label provider_requestpoint_label_inprogress font_bold';
    }

    requestpointLabel.requestLayout();
};

/**
 * Requests a point.
 */

exports.requestPoint = function() {
    if (pointState == global.CONST.POINTREQUESTSTATE.OUTOFRANGE) {
        exports.getDistance(container.store);
    } else if (pointState == global.CONST.POINTREQUESTSTATE.INRANGE) {
        var date = new Date().getTime();
        exports.request = {
            created:        date,
            customer:       settings.getString(global.CONST.USER.ID), 
            status:         'P', 
            displayName:    global.firebaseController.getUserName()
        };
        
        global.firebaseController.query({
            path: '/customers/' + settings.getString(global.CONST.USER.ID) + '/birthday'
        }).then(function(result) {
            if (result) {
                exports.request.birthday = result;
            }

            exports.DBPath = '/openPointRequests/' + container.provider.id + '/' + container.store.id + '/' + settings.getString(global.CONST.USER.ID) + date;
            var counter = 0;

            global.firebaseController.getFirebase().addValueEventListener(function(result) {
                counter++;

                if (counter == 3) {
                    exports.removeListeners();
                    exports.getDistance(container.store);
                }
            }, exports.DBPath).then(function(listenerWrapper) {
                container.listener = { 
                    listeners: listenerWrapper.listeners,
                    path:      listenerWrapper.path
                };
            });
       
            global.firebaseController.setValue({
                path:   exports.DBPath,
                value:  exports.request
            });

            exports.setRequestPointState(global.CONST.POINTREQUESTSTATE.INPROGRESS);
        });
    }
};

exports.changeValue = function(container, valuelabel, value, callback) {
    container.style.opacity = 0;
    container.scaleX = 1;
    container.scaleY = 1;
    container.rotate = 0;
    valuelabel.text = value;
    valuelabel.requestLayout();

    container.animate({
        scale:      { x: 1, y: 1 },
        rotate:     360,
        opacity:    1,
        curve:      enums.AnimationCurve.easeOut,
        duration:   500
    }).then(callback)
};

exports.changeTotalPoints = function(value) {
    exports.changeValue(container.getViewById('freebiecontainer'), freebie, value[0], function() {
        exports.changeValue(container.getViewById('actualpointcontainer'), actualpoint, value[1], function() {
            exports.changeValue(container.getViewById('totalpointscontainer'), totalpoints, value[2], function() {
            });
        });
    });
};

exports.selectStore = function() {
    container.notify({
        eventName:  global.CONST.EVENT.SELECTSTORE,
        store:      container.provider.store
    });
};

/**
 * Shows the selected store on the provider item.
 */

exports.setStore = function(store) {

    // Showing the name of the store

    storeName.text = store ? store.name : '';
    container.store = store;

    if (store) {
        exports.getDistance(store);
    }
};

exports.removeListeners = function() {
    
    // Removing the registered listeners

    if (container.listener) {
        global.firebaseController.getFirebase().removeEventListeners(
            container.listener.listeners,
            container.listener.path
        );

        container.listener = undefined;
    }
};

exports.removePointListener = function() {
    
    // Removing the registered listeners

    if (container.pointlistener) {
        global.firebaseController.getFirebase().removeEventListeners(
            container.pointlistener.listeners,
            container.pointlistener.path
        );

        container.pointlistener = undefined;
    }
};

exports.refreshPuzzle = function(balance) {
    var pw = container.getViewById('puzzle_watermark');

    if (balance < 10) {
        pw.src = 'res://puzzle' + balance;
        pw.visibility = 'visible';
    } else {
        pw.visibility = 'collapse';
    }
};

exports.approvePoint = function() {
    exports.request.status = 'A';
    exports.request.actionedAmount = 1;
    
    global.firebaseController.setValue({
        path:   exports.DBPath + '/',
        value:  exports.request
    });
};
