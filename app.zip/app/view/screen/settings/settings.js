'use strict';

/*
Copyright (C) 2017 Andras Sarvari <andras.sarvari@sarvaria.net>

Permission to use, copy, modify, and/or distribute this software for any
purpose with or without fee is hereby granted, provided that the above
copyright notice and this permission notice appear in all copies.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
*/

// Loading required modules

var settings = require('application-settings');
var layout = require('ui/layouts/stack-layout');
var labelModule = require('ui/label');
var switchModule = require('ui/switch');
var frameModule = require('ui/frame');

// Declaring module level variables

var container;
var personaldataSeparator;
var usernameLabel;
var username;
var borndateLabel;
var borndate;
var networkSeparator;
var mobileinternetLabel;
var mobileinternetSwitcher;
var notificationCategorySeparator;
var notificationCategoryContainer;
var locationInterestSeparator;
var locationInterestContainer;
//var logoutSeparator;
//var logoutButton;

/**
 * Event that fires when the screen has been loaded.
 * 
 * @param   event {Object}      event object
 */

exports.onLoaded = function(event) {

    // Initializing

    container = event.object;
    container.leftButton = global.CONST.BUTTON.BACK;
    container.showSettings = true;
    container.title = global.locale.screen.settings.title;
    container.onOpen = exports.onOpen;
    container.refreshBornDate = exports.refreshBornDate;
    container.clearNotificationCategories = exports.clearNotificationCategories;
    container.addNotificationCategory = exports.addNotificationCategory;
    container.refreshNotificationCategories = exports.refreshNotificationCategories;

    // Getting the referenced widgets in the container

    personaldataSeparator = container.getViewById('personaldata_separator');
    usernameLabel = container.getViewById('username_label');
    username = container.getViewById('username');
    borndateLabel = container.getViewById('borndate_label');
    borndate = container.getViewById('borndate');
    networkSeparator = container.getViewById('network_separator');
    mobileinternetLabel = container.getViewById('mobileinternet_label');
    mobileinternetSwitcher = container.getViewById('mobileinternet_switcher');
    notificationCategorySeparator = container.getViewById('notificationcategory_separator');
    notificationCategoryContainer = container.getViewById('notificationcategory_container');
    locationInterestSeparator = container.getViewById('locationinterest_separator');
    locationInterestContainer = container.getViewById('locationinterest_container');
    //logoutSeparator = container.getViewById('logout_separator');
    //logoutButton = container.getViewById('logout_button');

    // Localize the screen

    personaldataSeparator.text = global.locale.screen.settings.personaldata.title;
    usernameLabel.text = global.locale.screen.settings.personaldata.username;
    borndateLabel.text = global.locale.screen.settings.personaldata.borndate;
    networkSeparator.text = global.locale.screen.settings.network.title;
    mobileinternetLabel.text = global.locale.screen.settings.network.mobileinternet;
    notificationCategorySeparator.text = global.locale.screen.settings.notificationcategory.title;
    locationInterestSeparator.text = global.locale.screen.settings.locationinterest.title;
    //logoutSeparator.text = global.locale.screen.settings.logout.title;
    //logoutButton.text = global.locale.screen.settings.logout.logout;
};

/**
 * Event that fires when the screen opened.
 * 
 * @param   {Object} context    application context
 */

exports.onOpen = function(context) {

    // Setting the name of the current user

    username.text = global.firebaseController.getUserName();
    
    // Setting the born date

    exports.refreshBornDate();
    
    // Setting the mobile internet

    mobileinternetSwitcher.checked = settings.getBoolean(
        global.CONST.USER.MOBILEINTERNET, true
    );
    exports.redrawSwitcher(
        mobileinternetSwitcher,
        mobileinternetSwitcher.checked
    );

    // Setting notification categories

    global.firebaseController.query({ path: '/notificationCategories' }).then(function(result) {
        var items = [];

        for (var key in result) {
            if (result.hasOwnProperty(key)) {
                items.push({ id: key, name: result[key].title[global.locale.language], selected: false });
            }
        }

        global.firebaseController.query({ path: '/customers/' + settings.getString(global.CONST.USER.ID) + '/notificationCategoryInterests' }).then(function(selection) {
            for (var key in selection) {
                if (selection.hasOwnProperty(key)) {
                    for (var i = 0; i < items.length; i++) {
                        if (items[i].id == key) {
                            items[i].selected = selection[key];
                            break;
                        }
                    }
                }
            }

            // Ordering

            items.sort(function(a, b) {
                if (a.name < b.name) {
                    return -1;
                } else if (a.name > b.name) {
                    return 1;
                } else {
                    return 0;
                }
            });

            exports.refreshNotificationCategories(items);
        });
    });            

    // Setting location interests

    global.firebaseController.query({ path: '/locations' }).then(function(result) {
        var items = [];

        for (var key in result) {
            if (result.hasOwnProperty(key)) {
                items.push({ id: key, name: result[key].city + (result[key].locales[global.locale.language] ? (', ' + result[key].locales[global.locale.language]) : ''), selected: false });
            }
        }

        global.firebaseController.query({ path: '/customers/' + settings.getString(global.CONST.USER.ID) + '/locationInterests' }).then(function(selection) {
            for (var key in selection) {
                if (selection.hasOwnProperty(key)) {
                    for (var i = 0; i < items.length; i++) {
                        if (items[i].id == key) {
                            items[i].selected = selection[key];
                            break;
                        }
                    }
                }
            }

            // Ordering

            items.sort(function(a, b) {
                if (a.name < b.name) {
                    return -1;
                } else if (a.name > b.name) {
                    return 1;
                } else {
                    return 0;
                }
            });

            exports.refreshLocationInterests(items);
        });
    });            
};

/**
 * Event that fires when the mobile internet switcher changed.
 */

exports.mobilinternetChanged = function() {
    exports.redrawSwitcher(mobileinternetSwitcher);
};

/**
 * Toggles the mobile internet switcher.
 */

exports.toggleMobileInternet = function() {
    exports.redrawSwitcher(mobileinternetSwitcher);
    mobileinternetSwitcher.checked = !mobileinternetSwitcher.checked;
};

/**
 * Redraws the switcher.
 */

exports.redrawSwitcher = function(switcher, state) {
    switcher.style.color = (state == undefined ? 
                            !switcher.checked : state) ? 
                            '#F76830' : '#808080';
};

/**
 * Fires the born date set event.
 */

exports.setBornDate = function() {
    container.notify({
        eventName:  global.CONST.EVENT.SETBORNDATE
    });
};

/**
 * Refreshes the born date from the settings.
 */

exports.refreshBornDate = function() {

    // Getting the born date of the user from the Firebase DB

    global.firebaseController.query({
        path: '/customers/' + settings.getString(global.CONST.USER.ID) + '/birthday'
    }).then(function(result) {
        if (result != undefined) {
            var date = new Date(result);

            // Refreshing the date o the screen

            borndate.text = 
            date.getFullYear() + '.' + 
            '00'.substring(('' + (date.getMonth() + 1)).length) + (date.getMonth() + 1) + '.' + 
            '00'.substring(('' + date.getDate()).length) + date.getDate()
        } else {
            borndate.text = '';
        }
    });
};

/**
 * Refreshes the notification categories.
 */

exports.refreshNotificationCategories = function(items) {

    // Removing all of the notification categories

    notificationCategoryContainer.removeChildren();

    for (var i = 0; i < items.length; i++) {
        var item = new layout.StackLayout();
        item.className = 'settings_item';
        item.orientation = 'horizontal';

        var label = new labelModule.Label();
        label.id = 'ncl___' + items[i].id;
        label.className = 'settings_label';
        label.text = items[i].name;

        label.on('tap', function(event) {
            var sw = container.getViewById('nc___' + event.object.id.split('___')[1]);
            exports.redrawSwitcher(sw);
            sw.checked = !sw.checked;

            global.firebaseController.setValue({
                path:   '/customers/' + settings.getString(global.CONST.USER.ID) + '/notificationCategoryInterests/' + event.object.id.split('___')[1],
                value:  sw.checked
            });
        });

        item.addChild(label);

        var switchHolder = new layout.StackLayout();
        switchHolder.id = 'nch___' + items[i].id;
        switchHolder.className = 'settings_value';
        switchHolder.orientation = 'vertical';
        switchHolder.width = '100%';

        var switcher;

        switchHolder.on('tap', function(event) {
            var sw = container.getViewById('nc___' + event.object.id.split('___')[1]);
            exports.redrawSwitcher(sw);
            sw.checked = !sw.checked;

            global.firebaseController.setValue({
                path:   '/customers/' + settings.getString(global.CONST.USER.ID) + '/notificationCategoryInterests/' + event.object.id.split('___')[1],
                value:  sw.checked
            });
        });

        switcher = new switchModule.Switch();
        switcher.id = 'nc___' + items[i].id;
        switcher.horizontalAlignment = 'right';
        switcher.className = 'settings_switcher';
        switcher.checked = items[i].selected;
        
        switcher.on('tap', function(event) {
            exports.redrawSwitcher(event.object);

            global.firebaseController.setValue({
                path:   '/customers/' + settings.getString(global.CONST.USER.ID) + '/notificationCategoryInterests/' + event.object.id.split('___')[1],
                value:  !event.object.checked
            });
        });

        switchHolder.addChild(switcher);
        item.addChild(switchHolder);

        notificationCategoryContainer.addChild(item);
        exports.redrawSwitcher(switcher, switcher.checked);
    }
};

exports.refreshLocationInterests = function(items) {

    // Removing all of the location interests

    locationInterestContainer.removeChildren();

    for (var i = 0; i < items.length; i++) {
        var item = new layout.StackLayout();
        item.className = 'settings_item';
        item.orientation = 'horizontal';

        var label = new labelModule.Label();
        label.id = 'lil___' + items[i].id;
        label.className = 'settings_label';
        label.text = items[i].name;

        label.on('tap', function(event) {
            var sw = container.getViewById('li___' + event.object.id.split('___')[1]);
            exports.redrawSwitcher(sw);
            sw.checked = !sw.checked;

            global.firebaseController.setValue({
                path:   '/customers/' + settings.getString(global.CONST.USER.ID) + '/locationInterests/' + event.object.id.split('___')[1],
                value:  sw.checked
            });            
        });

        item.addChild(label);

        var switchHolder = new layout.StackLayout();
        switchHolder.id = 'lih___' + items[i].id;
        switchHolder.className = 'settings_value';
        switchHolder.orientation = 'vertical';
        switchHolder.width = '100%';

        var switcher;

        switchHolder.on('tap', function(event) {
            var sw = container.getViewById('li___' + event.object.id.split('___')[1]);
            exports.redrawSwitcher(sw);
            sw.checked = !sw.checked;

            global.firebaseController.setValue({
                path:   '/customers/' + settings.getString(global.CONST.USER.ID) + '/locationInterests/' + event.object.id.split('___')[1],
                value:  sw.checked
            });
        });

        switcher = new switchModule.Switch();
        switcher.id = 'li___' + items[i].id;
        switcher.horizontalAlignment = 'right';
        switcher.className = 'settings_switcher';
        switcher.checked = items[i].selected;
        
        switcher.on('tap', function(event) {
            exports.redrawSwitcher(event.object);

            global.firebaseController.setValue({
                path:   '/customers/' + settings.getString(global.CONST.USER.ID) + '/locationInterests/' + event.object.id.split('___')[1],
                value:  !event.object.checked
            });
        });

        switchHolder.addChild(switcher);
        item.addChild(switchHolder);

        locationInterestContainer.addChild(item);
        exports.redrawSwitcher(switcher, switcher.checked);
    }
};

/**
 * Logs out the current user.
 */

exports.logout = function() {

    // Logging out

    global.firebaseController.logout();
    
    // Showing the login page

    frameModule.topmost().navigate({
        moduleName:     './view/screen/login/login-page',
        animated:       true,
        transition: {
            name:       'flipLeft',
            duration:   600,
            curve:      'easeIn'
        }
    });
};
