/*
Copyright (C) 2017 Andras Sarvari <andras.sarvari@sarvaria.net>

Permission to use, copy, modify, and/or distribute this software for any
purpose with or without fee is hereby granted, provided that the above
copyright notice and this permission notice appear in all copies.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
*/

// Loading required modules

var application = require('application');
var Geolocation = require('nativescript-geolocation');
var GoogleMaps = require('nativescript-google-maps-sdk');
var enums = require('ui/enums');
var Image = require('ui/image').Image;
var imageSource = require('image-source');
var layout = require('ui/layouts/stack-layout');
var labelModule = require('ui/label');
var Observable = require('data/observable').Observable;
var BarChart = require('../../barchart/barchart').BarChart;

// Declaring constanses

const DEFAULT_ZOOM_LEVEL = 16;

// Declare module level variables

var container;
var search;
var storeinfo;
var barchart;
var mapView;
var markers;
var selectedMarker;
var storeinfoState;
var combo;
var storeContainer;
var positionMarker;
var mapSearchBox;
var myLocation;
var stores;
var storeName;
var liveLabel;
var mapReady;
var selection;
var registerImage;

// Declaring module level variables

var container;

/**
 * Event that fires when the screen has been loaded.
 * 
 * @param   event       event object
 */

exports.onLoaded = function(event) {

    // Getting the container and propagating the public methods

    container = event.object;
    container.onOpen = exports.onOpen;
    container.refreshRegisterImage = exports.refreshRegisterImage;
    container.hideActionbar = true;
    search = container.getViewById('search');    
    storeinfo = container.getViewById('storeinfo');    
    combo = container.getViewById('combo');
    storeContainer =  container.getViewById('storecontainer');
    barchart = container.getViewById('barchart');
    mapSearchBox = container.getViewById('mapsearchbox');
    myLocation = container.getViewById('mylocation');
    storeName = container.getViewById('storename');
    hours = container.getViewById('hours');
    openstate = container.getViewById('openstate');
    opentime = container.getViewById('opentime');
    registerImage = container.getViewById('registerimage');
    addressLabel = container.getViewById('addresslabel');
    address = container.getViewById('address');
    phoneLabel = container.getViewById('phonelabel');
    phone = container.getViewById('phone');
    populartimesLabel = container.getViewById('populartimes');
    populartimesstate = container.getViewById('populartimesstate');
    liveLabel = container.getViewById('live');
    mapReady = false;

    // Localizing

    hours.text = global.locale.screen.providerinfo.hours;    
    addressLabel.text = global.locale.screen.providerinfo.address;
    phoneLabel.text = global.locale.screen.providerinfo.phone;
    populartimesLabel.text = global.locale.screen.map.populartimes;
    liveLabel.text = global.locale.screen.map.live;

    var model = new Observable();
    model.set('search', '');

    model.addEventListener(Observable.propertyChangeEvent, function (event) {
        if (typeof(event.value) === 'string') {
            combo.visibility = 'visible';
            exports.filterCombo(event.value);
        }
    });
    
    container.bindingContext = model;
    
    // Preparing the marker holder

    storeinfoState = 0;

    storeinfo.animate({
        translate: { x: 0, y: 280 },    
        curve: enums.AnimationCurve.easeOut,
        duration:   1
    }).then(function() {
        
    });
};

/**
 * Event that fires when the screen opened.
 */

exports.onOpen = function() {
    
    // Setting the current position

    search.width = (global.screenSize.widthDP - 8 - 8) + 'dp';
    storeinfo.width = global.screenSize.widthDP + 'dp';
    mapSearchBox.width = (global.screenSize.widthDP - 96) + 'dp';
    myLocation.top = (global.screenSize.heightDP - 56 - 56 - 92) + 'dp';
    mapSearchBox.dismissSoftInput();
    
    exports.setCurrentPosition();

    if (mapReady) {
        exports.filterCombo(container.bindingContext.get('search'));
    }
};
    
/**
 * Event that fires when the Google Maps is ready.
 * 
 * @param   event       event object
 */

exports.onMapReady = function(event) {
    
    // Getting the map view

    mapView = event.object;
    mapReady = true;

    // Creating the markers for the stores

    markers = [];
    
    var addStore = function(provider, store) {
        var gps = store.gps.split(',');

        var storeMarker = new GoogleMaps.Marker();
        storeMarker.position = GoogleMaps.Position.positionFromLatLng(gps[0].trim(), gps[1].trim());
        var icon = new Image();
        icon.imageSource = imageSource.fromResource('pin_unselected');
        storeMarker.icon = icon;
        storeMarker.userData = { provider: provider, store: store };
        mapView.addMarker(storeMarker);
    
        markers.push(storeMarker);
    };

    global.DB.loadProviders().then(function(items) {
        stores = [];

        for (var i = 0; i < items.length; i++) {
            for (var j = 0; j < items[i].store.length; j++) {
                stores.push({ provider: items[i], store: items[i].store[j] });
            }                
        }

        for (var i = 0; i < stores.length; i++) {
            addStore(stores[i].provider, stores[i].store);
        }

        exports.filterCombo('');
    });    
};

/**
 * Shows the specified marker on the map by positioning to it.
 * 
 * @param   marker      marker that has to show
 */

exports.positionToMarker = function(marker) {
    
    if (marker) {
        if (application.android) {

            // Showing the marker by animation

            mapView.gMap.animateCamera(
                com.google.android.gms.maps.CameraUpdateFactory.newLatLngZoom(
                    new com.google.android.gms.maps.model.LatLng(
                        marker.position.latitude,
                        marker.position.longitude
                    ), DEFAULT_ZOOM_LEVEL
                )
            );
        } else {

            // Showing the marker

            container.bindingContext.set('latitude', marker.position.latitude);
            container.bindingContext.set('longitude', marker.position.longitude);
            
            GoogleMaps.mainViewModel.set('zoom', DEFAULT_ZOOM_LEVEL);
        }
    }
};
    
/**
 * Sets the current position of the map to the user's position.
 */

exports.setCurrentPosition = function() {

    // Getting the current GPS position

    Geolocation.getCurrentLocation({
        desiredAccuracy:    enums.Accuracy.high, 
        updateDistance:     0, 
        timeout:            30000
    }).then(function(location) {

        // Creating a maker for the current position
        
        if (positionMarker) {
            positionMarker.position = GoogleMaps.Position.positionFromLatLng(
                location.longitude,
                location.latitude
            );
        } else {
            positionMarker = new GoogleMaps.Marker();
            positionMarker.position = GoogleMaps.Position.positionFromLatLng(
                location.longitude,
                location.latitude
            );
            positionMarker.title = 'You are here'
            positionMarker.userData = { yourposition: true };
            mapView.addMarker(positionMarker);
        }

        // Showing the marker

        exports.positionToMarker(positionMarker);
    }, function(error) {

        // Error occured during GPS obtaining

        alert(error.message);
    });
};

exports.showMyLocation = function() {
    exports.positionToMarker(positionMarker);
};

exports.markerSelected = function(event) {
    mapSearchBox.dismissSoftInput();

    if (!event.marker.userData.yourposition) {
        exports.deselectMarker();

        var icon = new Image();
        icon.imageSource = imageSource.fromResource('pin_selected');
        event.marker.icon = icon;
        selectedMarker = event.marker;
        
        storeinfoState = 1;
        
        selection = selectedMarker.userData;
        var provider = selection.provider;
        var store = selection.store;

        // Showing register image

        registerImage.src = (provider && provider.selected ? 
                            'res://favorite_highlight' :
                            'res://favorites_unselected');

        // Showing the name of the store
        
        storeName.text = store.name;

        // Showing the store address

        address.text = store ? store.address : '';
        
        // Showing the store phone

        phone.text = store ? store.phone : '';
        
        // Showing openstate and opentime

        openstate.text = store && store.open ?
        global.locale.screen.map.open :
        global.locale.screen.map.close;
        opentime.text = store && store.open ? 
        ('(' + gobal.locale.screen.map.opentime + ')') :
        '';

        // Showing popular times

        populartimesstate.text = global.locale.screen.map.populartimesstate;
    
        storeinfo.animate({
            translate: { x: 0, y: 208 + 1 },
            curve: enums.AnimationCurve.easeOut,
            duration:   160
        });
    }
};

exports.storeInfoSelected = function() {
    if (storeinfoState == 2) {
        exports.hideStoreStatistics();
    } else {
        exports.showStoreStatistics();
    }
};

exports.storeStatisticsSelected = function() {
    exports.hideStoreStatistics();
};

exports.deselectMarker = function() {
    if (selectedMarker) {
        var icon = new Image();
        icon.imageSource = imageSource.fromResource('pin_unselected');
        selectedMarker.icon = icon;
        selectedMarker = null;
    }
};

exports.hideStoreInfo = function() {
    mapSearchBox.dismissSoftInput();
    combo.visibility = 'collapse';
    exports.deselectMarker();

    if (storeinfoState > 0) {
        storeinfoState = 0;
        
        storeinfo.animate({
            translate: { x: 0, y: 280 },    
            curve: enums.AnimationCurve.easeOut,
            duration:   160
        });
    }
};

exports.showStoreStatistics = function() {
    storeinfoState = 2;
    
    new BarChart().refresh(barchart, [2, 5, 10, 15, 18, 17, 23, 32, 36, 45, 52, 48, 46, 47, 23, 22, 11, 22]);

    storeinfo.animate({
        translate: { x: 0, y: 0 },    
        curve: enums.AnimationCurve.easeOut,
        duration:   160
    });
};

exports.hideStoreStatistics = function() {
    if (storeinfoState == 2) {
        storeinfoState = 1;
        
        storeinfo.animate({
            translate: { x: 0, y: 208 + 1 },    
            curve: enums.AnimationCurve.easeOut,
            duration:   160
        });
    }        
};

exports.toggleRegister = function(event) {
    container.notify({
        eventName:  selection.provider.selected ? global.CONST.EVENT.UNSUBSCRIBE : 
                                                  global.CONST.EVENT.SUBSCRIBE,
        provider:   JSON.stringify(selection.provider)
    });
};

exports.toggleCombo = function() {
    mapSearchBox.dismissSoftInput();
    combo.visibility = (combo.visibility == 'visible' ? 'collapse' : 'visible');
};

exports.filterCombo = function(value) {

    // Clearing the content of the combo

    storeContainer.removeChildren();
    
    var v = value.toLowerCase();
    var count = 0;

    for (var i = 0; i < stores.length; i++) {
        if (stores[i].store.name.toLowerCase().indexOf(v) >= 0) {
            var item = new layout.StackLayout();
            item.id = 'mapstoreid___' + stores[i].store.id;
            item.className = 'map_store_combo_item';
            item.verticalAlignment = 'center';
            
            item.on('tap', function(event) {
                combo.visibility = 'collapse';

                id = event.object.id.split('___')[1];

                if (markers) {
                    for (var j = 0; j < markers.length; j++) {
                        if (markers[j].userData.store.id == id) {
                            exports.positionToMarker(markers[j]);
                            break;
                        }
                    }
                }
            });

            var storeName = new labelModule.Label();
            storeName.text = stores[i].store.name;
            storeName.className = 'map_store_combo_item_label font_regular';
            item.addChild(storeName);

            storeContainer.addChild(item);
            count++;
        }
    }

    combo.height = (count >= 4 ? 224 : (count * 56)) + 'dp';
};

exports.showStoreInfo = function() {
    container.notify({
        eventName:  global.CONST.EVENT.SHOWPROVIDERINFO,
        provider:   selection.provider
    });
};

exports.refreshRegisterImage = function(selected) {
    selection.selected = selected;
    registerImage.src = selected ? 
                        'res://favorite_highlight' :
                        'res://favorites_unselected';
};
