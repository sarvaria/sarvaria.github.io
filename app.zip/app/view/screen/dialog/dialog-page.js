/*
Copyright (C) 2017 Andras Sarvari <andras.sarvari@sarvaria.net>

Permission to use, copy, modify, and/or distribute this software for any
purpose with or without fee is hereby granted, provided that the above
copyright notice and this permission notice appear in all copies.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
*/

// Loading required modules

var settings = require('application-settings');

// Declaring constanses

// Declaring module level variables

var container;
var callback;
var provider;
var providerName;

exports.onShownModally = function(event) {
    provider = JSON.parse(event.context);
    providerName.text = provider.name;    
    callback = event.closeCallback;
}

/**
 * Event that fires when the screen has been loaded.
 * 
 * @param   event       event object
 */

exports.onLoaded = function(event) {

    // Getting the container and propagating the public methods

    container = event.object;
    providerName = container.getViewById('providername');
    settings.setBoolean(global.CONST.SCREEN.UNSUBSCRIBE, true);
};

/**
 * Event that fires when the screen has been unloaded.
 * 
 * @param   event       event object
 */

exports.onUnloaded = function() {

    // Removing the registered events

    settings.remove(global.CONST.SCREEN.UNSUBSCRIBE);
};

/**
 * Event that fires when the user cancels the dialog.
 */

exports.cancel = function() {
    callback(global.CONST.EVENT.CANCEL);
};

exports.empty = function() {
};

exports.unsubscribe = function() {
    callback(global.CONST.EVENT.UNSUBSCRIBE);
};
