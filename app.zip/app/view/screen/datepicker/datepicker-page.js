/*
Copyright (C) 2017 Andras Sarvari <andras.sarvari@sarvaria.net>

Permission to use, copy, modify, and/or distribute this software for any
purpose with or without fee is hereby granted, provided that the above
copyright notice and this permission notice appear in all copies.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
*/

// Loading required modules

var settings = require('application-settings');

// Declaring module level variables

var container;
var datepicker;
var callback;

exports.onShownModally = function(args) {
    callback = args.closeCallback;
}
/**
 * Event that fires when the screen has been loaded.
 * 
 * @param   event       event object
 */

exports.onLoaded = function(event) {

    // Getting the container and propagating the public methods

    container = event.object;
    settings.setBoolean(global.CONST.SCREEN.BORNDATE, true);
    datepicker = container.getViewById('datepicker');

    global.firebaseController.query({
        path: '/customers/' + settings.getString(global.CONST.USER.ID) + '/birthday'
    }).then(function(result) {
        var date = new Date(result);

        datepicker.set('day', date.getDate());
        datepicker.month = date.getMonth() + 1;
        datepicker.year = date.getFullYear();
    });
};

/**
 * Event that fires when the screen has been unloaded.
 * 
 * @param   event       event object
 */

exports.onUnloaded = function() {

    // Removing the registered events

    settings.remove(global.CONST.SCREEN.BORNDATE);
};

/**
 * Empty tap event handler.
 */

exports.empty = function() {};

/**
 * Event that fires when the user cancels the dialog.
 */

exports.cancel = function() {
    callback(global.CONST.EVENT.CANCEL);
};

/**
 * Event that fires when the user taps the OK button.
 */

exports.save = function() {
    if (datepicker.date) {
        var year = '' + datepicker.date.getFullYear();
        var month = '' + (datepicker.date.getMonth() + 1);
        var day = '' + datepicker.date.getDate();

        callback(
            year + '.' + 
            '00'.substring(month.length) + month + '.' + 
            '00'.substring(day.length) + day
        );
    } else {
        callback(global.CONST.EVENT.CANCEL);
    }
};
