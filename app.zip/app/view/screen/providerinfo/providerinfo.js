'use strict';

/*
Copyright (C) 2017 Andras Sarvari <andras.sarvari@sarvaria.net>

Permission to use, copy, modify, and/or distribute this software for any
purpose with or without fee is hereby granted, provided that the above
copyright notice and this permission notice appear in all copies.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
*/

// Loading required modules

var application = require('application');
var utils = require('utils/utils');
var BarChart = require('../../barchart/barchart').BarChart;
var GoogleMaps = require('nativescript-google-maps-sdk');
var Image = require('ui/image').Image;
var imageSource = require('image-source');
var labelModule = require('ui/label');

// Declaring constanses

const DEFAULT_ZOOM_LEVEL = 16;

// Declaring module level variables

var container;
var providername;
var storeName;
var hours;
var openstate;
var opentime;
var registerImage;
var scrollArea;
var directionsButton;
var websiteButton;
var barchart;
var addressLabel;
var address;
var phoneLabel;
var phone;
var populartimesLabel;
var populartimesstate;
var liveLabel;
var keywordsContainer;
var mapView;
var marker;

/**
 * Event that fires when the screen has been loaded.
 * 
 * @param   event       event object
 */

exports.onLoaded = function(event) {

    // Initializing

    container = event.object;
    container.onOpen = exports.onOpen;
    container.refreshRegisterImage = exports.refreshRegisterImage;
    container.setStore = exports.setStore;
    container.leftButton = global.CONST.BUTTON.BACK;
    container.showSettings = true;
    container.title = global.locale.screen.providerinfo.title;

    // Getting the components

    providername = container.getViewById('providername');
    storeName = container.getViewById('storename');
    hours = container.getViewById('hours');
    openstate = container.getViewById('openstate');
    opentime = container.getViewById('opentime');
    registerImage = container.getViewById('registerimage');
    scrollArea = container.getViewById('scrollarea');
    directionsButton = container.getViewById('directions');
    websiteButton = container.getViewById('website');
    barchart = container.getViewById('barchart');
    addressLabel = container.getViewById('addresslabel');
    address = container.getViewById('address');
    phoneLabel = container.getViewById('phonelabel');
    phone = container.getViewById('phone');
    populartimesLabel = container.getViewById('populartimes');
    populartimesstate = container.getViewById('populartimesstate');
    liveLabel = container.getViewById('live');
    keywordsContainer = container.getViewById('keywordscontainer');
    
    // Localizing

    hours.text = global.locale.screen.providerinfo.hours;    
    directionsButton.text = global.locale.screen.providerinfo.directions;
    websiteButton.text = global.locale.screen.providerinfo.website;
    addressLabel.text = global.locale.screen.providerinfo.address;
    phoneLabel.text = global.locale.screen.providerinfo.phone;
    populartimesLabel.text = global.locale.screen.providerinfo.populartimes;
    liveLabel.text = global.locale.screen.providerinfo.live;
};

/**
 * Event that fires when the screen opened.
 */

exports.onOpen = function() {

    // Showing provider data

    if (mapView) {
        exports.showProvider(container.data);
    }
    
    // Scrolling to top of the screen

    scrollArea.scrollToVerticalOffset(0, false);
    
    // Setting the width of the directions and homepage buttons

    directionsButton.width = parseInt((global.screenSize.widthDP - 32 - 32 - 12) / 2) + 'dp';
    websiteButton.width = directionsButton.width;
   
    // Refreshing the barchart

    new BarChart().refresh(
        barchart,
        [2, 5, 10, 15, 18, 17, 23, 32, 36, 45, 52, 48, 46, 47, 23, 22, 11, 22]
    );
};

/**
 * Event that fires when the Google Maps is ready.
 */

exports.onMapReady = function(event) {

    // Getting the map view

    mapView = event.object;

    // Disabling all user interactions

    mapView.settings.zoomControlsEnabled = false;
    mapView.settings.zoomGesturesEnabled = true;
    mapView.settings.scrollGesturesEnabled = false;
    mapView.settings.tiltGesturesEnabled = false;
    mapView.settings.rotateGesturesEnabled = false;
    mapView.settings.myLocationButtonEnabled = false;
    mapView.settings.mapToolbarEnabled = false;
    mapView.settings.indoorLevelPickerEnabled = false;
    mapView.settings.compassEnabled = false;

    // Showing the marker of the provider on the map

    marker = new GoogleMaps.Marker();
    marker.position = GoogleMaps.Position.positionFromLatLng(0, 0);
    var icon = new Image();
    icon.imageSource = imageSource.fromResource('pin_selected');
    marker.icon = icon;
    mapView.addMarker(marker);

    // Showing provider data

    exports.showProvider(container.data);
};

exports.setMarker = function(gps) {
    gps = gps.split(',');

    marker.position = GoogleMaps.Position.positionFromLatLng(
        parseFloat(gps[0].trim()), parseFloat(gps[1].trim())
    );
    
    // Showing the marker by animation

    if (application.android) {
        mapView.gMap.animateCamera(
            com.google.android.gms.maps.CameraUpdateFactory.newLatLngZoom(
                new com.google.android.gms.maps.model.LatLng(
                    marker.position.latitude,
                    marker.position.longitude
                ), DEFAULT_ZOOM_LEVEL
            )
        );
    } else {
        
        // Showing the marker

        container.bindingContext.set('latitude', marker.position.latitude);
        container.bindingContext.set('longitude', marker.position.longitude);
        
        GoogleMaps.mainViewModel.set('zoom', DEFAULT_ZOOM_LEVEL);
    }
};

/**
 * Event that fires when the register button tapped on the provider item.
 */

exports.toggleRegister = function(event) {

    // Fires the UNSUBSCRIBE event

    container.notify({
        eventName:  global.CONST.EVENT.UNSUBSCRIBE,
        provider:   '1'
    });
};

/**
 * Event that fires when the directions button tapped.
 */

exports.direction = function() {

    // Opens the Google Maps with navigation

    utils.openUrl('https://www.google.com/maps/dir/?api=1&origin=Space+Needle+Seattle+WA&destination=Pike+Place+Market+Seattle+WA&travelmode=bicycling');
};

/**
 * Event that fires when the homepage button tapped.
 */

exports.website = function() {

    // Opens the homepage of the provider in the default browser

    var website = container.data.website;

    if (website) {
        if (website.indexOf('http') < 0) {
            website = 'http://' + website;
        }

        utils.openUrl(website);
    }
};

/**
 * Event that fires when the store selection button tapped.
 */

exports.selectStore = function() {

    // Fires the SELECTSTORE event

    container.notify({
        eventName:  global.CONST.EVENT.SELECTSTORE,
        store:      container.data.store
    });
};

/**
 * Shows the selected store on the provider item.
 */

exports.setStore = function(store) {

    // Showing the name of the store
    
    storeName.text = store ? store.name : '';

    // Showing the provider address

    address.text = store ? store.address : '';
    
    // Showing the provider phone

    phone.text = store ? store.phone : '';

    // Showing the store on the map

    exports.setMarker((store && store.gps) ? store.gps : '0, 0');
    
    if (container.data && store) {
            
        global.DB.loadKeywords(container.data.id, store.id).then(function(keywords) {

            // Refreshing keywords

            exports.refreshKeywords(keywords);
        });
    } else {

        // Refreshing keywords

        exports.refreshKeywords([]);            
    }
};

/**
 * Shows the specified provider.
 * 
 * @param   {Object}    provider    provider that has to show
 */

exports.showProvider = function(provider) {

    // Showing provider name

    providername.text = provider ? provider.name : '';

    // Showing register image

    registerImage.src = (provider && provider.selected ? 
                        'res://favorite_highlight' :
                        'res://favorites_unselected');

    // Showing the store

    exports.setStore(
        provider && provider.store && provider.store.length > 0 ?
        provider.store[0] : {}
    );

    // Showing opensstate and opentime

    openstate.text = provider && provider.open ?
                     global.locale.screen.providerinfo.open :
                     global.locale.screen.providerinfo.close;
    opentime.text = provider && provider.open ? 
                    ('(' + gobal.locale.screen.providerinfo.opentime + ')') :
                    '';

    // Showing popular times

    populartimesstate.text = global.locale.screen.providerinfo.populartimesstate;
};

/**
 * Refreshes the keywords of the provider.
 *
 * @param   {Array} keywords    keywords of the provider
 */

exports.refreshKeywords = function(keywords) {

    // Removing all of the keywords

    keywordsContainer.removeChildren();

    // Adding the keywords
    
    keywords.forEach(function(item) {
        var keyword = new labelModule.Label();
        keyword.className = (item.selected ? 'providerinfo_keyword_selected' :
                            'providerinfo_keyword_unselected') +  ' font_regular';
        keyword.text = item.name;
        keywordsContainer.addChild(keyword);           
    });
};

/**
 * Event that fires when the register button tapped.
 */

exports.toggleRegister = function() {
    
    // Firing the SUBSCRIBE/UNSUBSCRIBE event for the selected provider

    container.notify({
        eventName:  container.data.selected ? global.CONST.EVENT.UNSUBSCRIBE : 
                                              global.CONST.EVENT.SUBSCRIBE,
        provider:   JSON.stringify(container.data)
    });
};

exports.refreshRegisterImage = function(selected) {
    container.data.selected = selected;
    registerImage.src = selected ? 
                        'res://favorite_highlight' :
                        'res://favorites_unselected';
};
