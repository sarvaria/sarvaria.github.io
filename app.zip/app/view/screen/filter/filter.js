/*
Copyright (C) 2017 Andras Sarvari <andras.sarvari@sarvaria.net>

Permission to use, copy, modify, and/or distribute this software for any
purpose with or without fee is hereby granted, provided that the above
copyright notice and this permission notice appear in all copies.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
*/

// Loading required modules

var settings = require('application-settings');
var layout = require('ui/layouts/absolute-layout');
var imageModule = require('ui/image');
var labelModule = require('ui/label');

// Declaring constanses

// Declaring module level variables

var container;
var filterContainer;

/**
 * Event that fires when the screen has been loaded.
 * 
 * @param   event       event object
 */

exports.onLoaded = function(event) {

    // Getting the container and propagating the public methods

    container = event.object;
    container.onOpen = exports.onOpen;
    container.leftButton = 'back';
    container.filterby = '';
    container.items = [];
    filterContainer = container.getViewById('filter_container');
};

/**
 * Event that fires when the screen has been unloaded.
 * 
 * @param   event       event object
 */

exports.onUnloaded = function() {

    // Removing the registered events

};

/**
 * Event that fires when the screen opened.
 */

exports.onOpen = function() {
    exports.refresh();
};

/**
 * Refreshes the filter items.
 */

exports.refresh = function() {

    // Determining the horizontal position of the checkmarks

    var checkmarkX = global.screenSize.widthDP - 32 - 32 - 24;

    // Clearing screen content

    filterContainer.removeChildren();

    var createItem = function(filteritem) {
        var key = 'filter_' + container.filterby + '___' + filteritem.id;
        
        var item = new layout.AbsoluteLayout();
        item.className = 'filter_item';

        var label = new labelModule.Label();
        label.className = 'filter_item_' + (settings.getBoolean(key) ? 'selected' : 'unselected') + ' font_regular';
        label.text = filteritem.name;
        label.top = '18dp';
        item.addChild(label);

        var checkmark = new imageModule.Image();
        checkmark.src = 'res://checkmark';
        checkmark.width = '24dp';
        checkmark.height = checkmark.width;
        checkmark.top = '18dp';
        checkmark.left = checkmarkX + 'dp';
        checkmark.visibility = (settings.getBoolean(key) ? 'visible' : 'collapse');
        item.addChild(checkmark);

        item.on('tap', function() {
            label.className = label.className == 'filter_item_selected font_regular' ? 'filter_item_unselected font_regular' : 'filter_item_selected font_regular';
            checkmark.visibility = checkmark.visibility == 'visible' ? 'collapse' : 'visible';
            settings.setBoolean(key, checkmark.visibility == 'visible');
        });

        return item;
    };

    for (var i = 0; i < container.items.length; i++) {
        filterContainer.addChild(createItem(container.items[i]));
    }
};
