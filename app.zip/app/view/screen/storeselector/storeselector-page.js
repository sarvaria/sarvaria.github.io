/*
Copyright (C) 2017 Andras Sarvari <andras.sarvari@sarvaria.net>

Permission to use, copy, modify, and/or distribute this software for any
purpose with or without fee is hereby granted, provided that the above
copyright notice and this permission notice appear in all copies.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
*/

// Loading required modules

var settings = require('application-settings');
var layout = require('ui/layouts/stack-layout');
var labelModule = require('ui/label');

// Declaring constanses

// Declaring module level variables

var container;
var callback;
var store;
var storeContainer;

exports.onShownModally = function(event) {
    store = JSON.parse(event.context);
    callback = event.closeCallback;
    settings.setBoolean(global.CONST.SCREEN.STORESELECTOR, true);

    for (var i = 0; i < store.length; i++) {
        var item = new layout.StackLayout();
        item.id = 'store___' + store[i].id;
        item.className = 'dialog_storeselector_store_button';
        item.orientation = 'horizontal';
        item.horizontalAlignment = 'center';
        item.width = '100%';

        item.on('tap', function(event) {
            var id = event.object.id.split('___')[1];
            
            for (var i = 0; i < store.length; i++) {
                if (store[i].id == id) {
                    callback(JSON.stringify(store[i]));
                    break;
                }
            }
        });

        var storeName = new labelModule.Label();
        storeName.className = 'dialog_storeselector_store_button_label font_bold';
        storeName.verticalAlignment = 'center';
        storeName.text = store[i].name;

        item.addChild(storeName);
        
        storeContainer.addChild(item);
    }
};

/**
 * Event that fires when the screen has been loaded.
 * 
 * @param   event       event object
 */

exports.onLoaded = function(event) {

    // Initializing

    container = event.object;
    storeContainer = container.getViewById('storecontainer');
};

/**
 * Event that fires when the screen has been unloaded.
 * 
 * @param   event       event object
 */

exports.onUnloaded = function() {

    // Removing the registered events

    settings.remove(global.CONST.SCREEN.STORESELECTOR);
};

/**
 * Event that fires when the user cancels the dialog.
 */

exports.cancel = function() {
    callback('cancel');
};
