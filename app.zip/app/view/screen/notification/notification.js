/*
Copyright (C) 2017 Andras Sarvari <andras.sarvari@sarvaria.net>

Permission to use, copy, modify, and/or distribute this software for any
purpose with or without fee is hereby granted, provided that the above
copyright notice and this permission notice appear in all copies.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
*/

// Loading required modules

var gridlayout = require('ui/layouts/grid-layout');
var layout = require('ui/layouts/stack-layout');
var imageModule = require('ui/image');
var labelModule = require('ui/label');
var gestures = require('ui/gestures');
var enums = require('ui/enums');

// Declaring constanses

// Declaring module level variables

var container;
var notificationContainer;
var swipedItems;
var openedNotificationContent;

/**
 * Event that fires when the screen has been loaded.
 * 
 * @param   event       event object
 */

exports.onLoaded = function(event) {

    // Getting the container and propagating the public methods

    container = event.object;
    container.onOpen = exports.onOpen;
    container.showSettings = true;
    container.title = global.locale.screen.notification.title;
    notificationContainer = container.getViewById('notification_container');

    swipedItems = [];
};

/**
 * Event that fires when the screen has been unloaded.
 * 
 * @param   event       event object
 */

exports.onUnloaded = function() {

    // Removing the registered events

};

/**
 * Event that fires when the screen opened.
 */

exports.onOpen = function() {

    exports.closeSlidedItems(true);

    // Loading notifications

    global.DB.loadNotifications().then(function(result) {

        // Refreshing the notifications on the screen
        
        exports.refresh(result);
    });
};

exports.tapNotification = function(content) {
    if (openedNotificationContent && content.height == 0) {
        openedNotificationContent.height = 0;
    }
    
    exports.closeSlidedItems();

    if (content.height == 0) {
        openedNotificationContent = content;
        content.height = '100%';
    } else {
        openedNotificationContent = undefined;
        content.height = 0;
    }
};

/**
 * Refreshes the notification items.
 */

exports.refresh = function(items) {

    // Determining the size of a message in pixels

    var messageSize = parseInt(
        global.screenSize.widthPX - 
        ((32 + 52 + 10 + 48 + 32) * global.screenSize.DP)
    );

    // Determining the size of an answer button in pixels

    var buttonSize = parseInt((
        global.screenSize.widthPX - 
        ((32 + 16 + 16 + 32) * global.screenSize.DP)
    ) / 3);

    // Clearing screen content

    notificationContainer.removeChildren();
    
    // Creates a notification item

    var createNotificationItem = function(notification) {
        
        var relativeLayout = new gridlayout.GridLayout();
        relativeLayout.height = '72dp';
        relativeLayout.className = 'notification_item_container';

        var buttonHolder = new layout.StackLayout();
        buttonHolder.verticalAlignment = 'center';
        buttonHolder.orientation = 'vertical';
        buttonHolder.width = '100%';
        buttonHolder.height = '72dp';

        var buttonInnerHolder = new layout.StackLayout();
        buttonInnerHolder.horizontalAlignment = 'right';
        buttonInnerHolder.orientation = 'horizontal';

        var infoButton = new layout.StackLayout();
        infoButton.className = 'notification_item_infobutton';
        infoButton.width = '72dp';
        infoButton.height = infoButton.width;
        infoButton.verticalAlignment = 'center';
        infoButton.horizontalAlignment = 'center';

        var infoIcon = new imageModule.Image();
        infoIcon.src = 'res://info';
        infoIcon.width = '24dp';
        infoIcon.height = infoIcon.width;
        infoButton.addChild(infoIcon);

        buttonInnerHolder.addChild(infoButton);

        var deleteButton = new layout.StackLayout();
        deleteButton.id = 'notificationdeletebutton___' + notification.id;
        deleteButton.className = 'notification_item_deletebutton';
        deleteButton.width = '72dp';
        deleteButton.height = infoButton.width;
        deleteButton.verticalAlignment = 'center';
        deleteButton.horizontalAlignment = 'center';

        deleteButton.on('tap', function(event) {
            exports.closeSlidedItems();

            // Deleting the notification

            var ind = event.object.id.split('___')[1];

            global.firebaseController.setValue({
                path:   '/customers/' + settings.getString(global.CONST.USER.ID) + '/notifications/' + ind,
                value:  null
            });

            // Loading notifications

            global.DB.loadNotifications().then(function(result) {
        
                // Refreshing the notifications on the screen
                
                exports.refresh(result);
            });
        });

        var deleteIcon = new imageModule.Image();
        deleteIcon.src = 'res://bin';
        deleteIcon.width = '24dp';
        deleteIcon.height = deleteIcon.width;
        deleteButton.addChild(deleteIcon);

        buttonInnerHolder.addChild(deleteButton);
        buttonHolder.addChild(buttonInnerHolder);
        relativeLayout.addChild(buttonHolder);

        // Declaring a new notification item

        var notificationItem = new layout.StackLayout();
        notificationItem.id = 'notificationitem___' + notification.id;
        notificationItem.className = 'notification_item';
        notificationItem.orientation = 'horizontal';
        notificationItem.verticalAlignment = 'center';
        notificationItem.style.marginLeft = 0;

        // Creating the provider picture

        var providerPicture = new imageModule.Image();
        providerPicture.src = notification.icon;
        providerPicture.className = 'notification_item_image';
        providerPicture.width = '52dp';
        providerPicture.height = providerPicture.width;
        notificationItem.addChild(providerPicture);
        
        var titleMessageContainer = new layout.StackLayout();
        titleMessageContainer.orientation = 'vertical';
        titleMessageContainer.width = messageSize + 'px';
        titleMessageContainer.height = '48dp';

        var title = new labelModule.Label();
        title.className = 'notification_item_title font_regular';
        title.text = notification.title;
        titleMessageContainer.addChild(title);

        var message = new labelModule.Label();
        message.className = 'notification_item_message font_regular';
        message.text = notification.message;
        titleMessageContainer.addChild(message);

        notificationItem.addChild(titleMessageContainer);

        var timeContainer = new layout.StackLayout();
        timeContainer.width = '48dp';

        if (notification.seen) {
            var time = new labelModule.Label();
            time.className = 'notification_item_time';
            time.horizontalAlignment = 'right';
            time.text = notification.time;
            timeContainer.addChild(time);
        } else {
            var newMessage = new layout.StackLayout();
            newMessage.className = 'notification_item_newmessageflag';
            newMessage.horizontalAlignment = 'right';
            timeContainer.addChild(newMessage);
        }

        notificationItem.addChild(timeContainer);
        
        notificationItem.on(gestures.GestureTypes.pan, function(event) {
            if (!notificationItem.swiping && Math.abs(event.deltaX) >= global.CONST.SCREEN.SWIPE_SENSITIVITY && (event.deltaX < 0 || event.deltaX > 0) && !((notificationItem.swiped && event.deltaX < 0) || (!notificationItem.swiped && event.deltaX > 0))) {
                if (!notificationItem.swiped) {
                    exports.closeSlidedItems();
                }

                notificationItem.swiping = true;
                notificationItem.animate({
                    translate: { x: !notificationItem.swiped && event.deltaX < 0 ? -144 : 0, y: 0 },
                    curve: enums.AnimationCurve.easeOut,
                    duration:   160
                }).then(function() {
                    notificationItem.swiping = false;
                });

                notificationItem.swiped = !notificationItem.swiped;

                var ind = notificationItem.id.split('___')[1];
                
                if (notificationItem.swiped) {
                    swipedItems.push(ind);
                } else {
                    for (var j = 0; j < swipedItems.length; j++) {
                        if (swipedItems[j] == ind) {
                            swipedItems.splice(j, 1);
                        }
                    }
                }
            }                
        });
    
        relativeLayout.addChild(notificationItem);

        // Returns the created notification item

        return relativeLayout;
    };

    // Creates a notification item

    var createNotificationContent = function(notificationItem, infoButton, notification) {

        // Declaring a new notification content

        var notificationContent = new layout.StackLayout();
        notificationContent.className = 'notification_content';
        notificationContent.orientation = 'vertical';
        notificationContent.height = 0;

        var question = new labelModule.Label();
        question.className = 'notification_content_question font_regular';
        question.text = notification.question;
        notificationContent.addChild(question);

        if (notification.answer) {
            for (var i = 0; i < notification.answer.length; i++) {
                var answerContainer = new layout.StackLayout();
                answerContainer.orientation = 'horizontal';

                var answerLetter = new labelModule.Label();
                answerLetter.className = 'notification_content_question_letter font_bold';
                answerLetter.text = String.fromCharCode(65 + i) + '.';
                answerContainer.addChild(answerLetter);

                var answerText = new labelModule.Label();
                answerText.className = 'notification_content_question_text font_regular';
                answerText.text = notification.answer[i];
                answerContainer.addChild(answerText);
                
                notificationContent.addChild(answerContainer);
            }
        }

        var answerButtonContainer = new layout.StackLayout();
        answerButtonContainer.className = 'notification_content_answercontainer';
        answerButtonContainer.orientation = 'horizontal';

        if (notification.answered) {
            var submitTime = new labelModule.Label();
            submitTime.className = 'notification_content_question_answerbox_submited_time font_regular';
            submitTime.text = 'Answer submitted: ' + notification.answered.time + '. |';
            answerButtonContainer.addChild(submitTime);

            var submitAnswer = new labelModule.Label();
            submitAnswer.className = 'notification_content_question_answerbox_submited_answer font_bold';
            submitAnswer.text = String.fromCharCode(65 + notification.answered.index) + '. ' + notification.answer[notification.answered.index];
            answerButtonContainer.addChild(submitAnswer);
        } else if (notification.answer) {
            for (var i = 0; i < notification.answer.length; i++) {
                var answerBox = new layout.StackLayout();
                answerBox.id = 'notification_content_answerbox_answerbutton___' + String.fromCharCode(97 + i) + '___' + notification.id;
                answerBox.className = 'notification_content_answerbox notification_content_answerbox_' + String.fromCharCode(97 + i);
                answerBox.width = buttonSize + 'px';
                answerBox.height = answerBox.width;
                answerBox.horizontalAlignment = 'center';
                answerBox.verticalAlignment = 'center';
                answerBox.orientation = 'horizontal';

                var answerBoxLetter = new labelModule.Label();
                answerBoxLetter.className = 'notification_content_question_answerbox_letter font_bold';
                answerBoxLetter.text = String.fromCharCode(65 + i);
                answerBoxLetter.verticalAlignment = 'center';
                answerBox.addChild(answerBoxLetter);

                answerBox.on('tap', function(event) {
                    var ind_answ = event.object.id.split('___');
                    
                    global.firebaseController.setValue({
                        path:   '/customers/' + settings.getString(global.CONST.USER.ID) + '/notifications/' + ind_answ[1] + '/response',
                        value:  ind_answ[2]
                    });
                });
        
                answerButtonContainer.addChild(answerBox);
            }
        }

        notificationContent.addChild(answerButtonContainer);

        notificationItem.on('tap', function() {
            exports.tapNotification(notificationContent);
        });

        infoButton.on('tap', function() {
            exports.tapNotification(notificationContent);
        });
        
        // Returns the created notification content

        return notificationContent;
    };

    for (var i = 0; i < items.length; i++) {
        /*var item = createNotificationItem({
            id:         '' + i,
            icon:       'res://icon',
            title:      'Lorem ipsum' + i,
            message:    'Lorem ipsum dolor sit amet quilint bium' + i,
            time:       'july ' + (i + 1) + '.',
            seen:       i % 3 == 0,
            question:   'Lorem ipsum dolor sit amet quilint bium',
            answer:     [
                'Choice 01',
                'Choice 02',
                'Choice 03'
            ],
            answered:   (i % 2 == 0 ? undefined : { time: 'MAY 20', index: 1 })
        });*/
        
        
        var item = createNotificationItem(items[i]);
        notificationContainer.addChild(item);
        //console.dir(items[i]);

        notificationContainer.addChild(createNotificationContent(
            item.getChildAt(1), item.getChildAt(0).getChildAt(0).getChildAt(0), items[i])
        );

        /*notificationContainer.addChild(createNotificationContent(
            item.getChildAt(1), item.getChildAt(0).getChildAt(0).getChildAt(0), {
                id: '' + i,
            icon:       'res://icon',
            title:      'Lorem ipsum' + i,
            message:    'Lorem ipsum dolor sit amet quilint bium' + i,
            time:       'july ' + (i + 1) + '.',
            seen:       i % 3 == 0,
            question:   'Lorem ipsum dolor sit amet quilint bium',
            answer:     [
                'Choice 01',
                'Choice 02',
                'Choice 03'
            ],
            answered:   (i % 2 == 0 ? undefined : { time: 'MAY 20', index: 1 })
        }));*/
    }
};

exports.closeSlidedItems = function(skipAnimation) {
    for (var i = 0; i < swipedItems.length; i++) {
        var notificationItem = container.getViewById('notificationitem___' + swipedItems[i]);

        if (skipAnimation) {
            notificationItem.translateX = 0;
        } else {
            notificationItem.swiping = true;
            notificationItem.animate({
                translate: { x: 0, y: 0 },
                curve: enums.AnimationCurve.easeOut,
                duration:   160
            }).then(function() {
                notificationItem.swiping = false;
            });
        }

        notificationItem.swiped = !notificationItem.swiped;
    }

    swipedItems = [];
};
