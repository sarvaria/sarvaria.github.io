'use strict';

/*
Copyright (C) 2017 Andras Sarvari <andras.sarvari@sarvaria.net>

Permission to use, copy, modify, and/or distribute this software for any
purpose with or without fee is hereby granted, provided that the above
copyright notice and this permission notice appear in all copies.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
*/

// Loading required modules

var settings = require('application-settings');
var layout = require('ui/layouts/stack-layout');
var gridlayout = require('ui/layouts/grid-layout');
var imageModule = require('ui/image');
var labelModule = require('ui/label');

// Declaring module level variables

var container;
var providerContainer;

/**
 * Event that fires when the screen has been loaded.
 * 
 * @param   event {Object}      event object
 */

exports.onLoaded = function(event) {

    // Initializing

    container = event.object;
    container.showSettings = true;
    container.leftButton = settings.getString(
        global.CONST.SCREEN.FAVORITES_SORTTYPE,
        global.CONST.BUTTON.SORTBYPOINT
    );
    container.title = global.locale.screen.favorites.title;
    container.onOpen = exports.onOpen;
    container.refresh = exports.refresh;
    providerContainer = container.getViewById('provider_container');
};

/**
 * Event that fires when the screen opened.
 * 
 * @param   {Object} context    application context
 */

exports.onOpen = function(context) {
    
    // Refreshing the providers on the screen if it does not refreshed yet
    
    //if (providerContainer.getChildrenCount() === 0) {
        exports.refresh(context.leftButton);
    //}
};

/**
 * Refreshes the provider list.
 * 
 * @param   sorttype {String}   type of the sort
 */

exports.refresh = function(sorttype) {

    // Determining the size of a provider in pixels

    var providerSize = (global.screenSize.widthPX - 
                       (80 * global.screenSize.DP)) / 2;

    // Determining the number of rows that can be see on the screen

    var numberOfRows = parseInt((global.screenSize.heightPX - 
                       (((2 * 56) + 28 + 8) * global.screenSize.DP)) / 
                       (providerSize + (16 * global.screenSize.DP))) + 1;

    // Creates a provider item template

    var createProviderTemplate = function(index) {

        // Declaring a new provider item template

        var providerItem = new layout.StackLayout();
        providerItem.width = providerSize + 'px';
        providerItem.height = providerSize + 'px';

        // Setting the margins of the provider item template

        providerItem.style.marginTop = '16dp';

        if (((numberOfRows * 2) - 2) <= index) {
            providerItem.style.marginBottom = '16dp';
        }

        if (index % 2 == 0) {
            providerItem.style.marginLeft = '32dp';
            providerItem.style.marginRight = '8dp';
        } else {
            providerItem.style.marginLeft = '8dp';
            providerItem.style.marginRight = '32dp';
        }

        // Returns the created provider item template

        return providerItem;
    };

    // Creates a provider item

    var createProvider = function(provider, index) {

        // Creating the provider item

        var providerItem = createProviderTemplate(index);
        var relativeLayout = new gridlayout.GridLayout();
        
        // Creating the provider picture
        
        var pPic = 'res://logo';
        var providerPicture = new imageModule.Image();
        providerPicture.src = pPic;
        providerPicture.width = (providerSize * 
                                (pPic ==
                                'res://logo' ? 0.7 : 1)) + 'px';
        providerPicture.height = providerPicture.width;
        relativeLayout.addChild(providerPicture);

        // Fading the provider picture

        var fade = new layout.StackLayout();
        fade.style.backgroundColor = '#000000';
        fade.style.opacity = 0.8;
        relativeLayout.addChild(fade);

        // Creating the provider info

        var providerInfo = new layout.StackLayout();
        providerInfo.height = providerItem.height;
        providerInfo.verticalAlignment = 'center';

        // Creating the provider name

        var providerName = new labelModule.Label();
        providerName.text = provider.name;
        providerName.className = 'favorites_providername font_regular';
        providerInfo.addChild(providerName);

        // Creating the points at the provider

        var point = new labelModule.Label();
        point.text = (provider.balance || 0) + '/' + (provider.maxPoint || 10);
        point.className = 'favorites_point font_bold';
        providerInfo.addChild(point);

        // Adding the provider info to the relative layout

        relativeLayout.addChild(providerInfo);
        
        // Adding the relative layout to the provider item

        providerItem.addChild(relativeLayout);

        // Adding tap event handler

        providerItem.on('tap', function() {

            // Firing the provider selected event

            container.notify({
                eventName:  global.CONST.EVENT.PROVIDER,
                provider:   provider
            });
        });
        
        // Returns the created provider item

        return providerItem;
    };

    // Creates the add button

    var createAddButton = function(index) {

        // Creating the add button

        var addButton = createProviderTemplate(index);
        addButton.style.backgroundColor = '#EFEFEF';
        addButton.verticalAlignment = 'center';
        addButton.horizontalAlignment = 'center';

        // Creating button image

        var image = new imageModule.Image();
        image.src = 'res://addnew';
        image.width = parseInt(providerSize / 2) + 'px';
        image.height = parseInt(providerSize / 2) + 'px';
        addButton.addChild(image);

        // Adding tap event handler

        addButton.on('tap', function() {
            container.notify({
                eventName:  global.CONST.EVENT.SEARCH
            });
        });
            
        // Returns the created add button

        return addButton;
    };

    // Creates an empty provider item

    var createEmptyProvider = function(index) {

        // Creating the empty provider item

        var emptyProviderItem = createProviderTemplate(index);
        emptyProviderItem.style.backgroundColor = '#EFEFEF';
        emptyProviderItem.verticalAlignment = 'center';
        emptyProviderItem.horizontalAlignment = 'center';

        // Creating empty provider watermark

        var image = new imageModule.Image();
        image.src = 'res://watermark_alternative';
        image.width = parseInt(providerSize / 2) + 'px';
        image.height = parseInt(providerSize / 2) + 'px';
        emptyProviderItem.addChild(image);

        // Returns the created empty provider item

        return emptyProviderItem;
    };

    // Getting the providers from the Firebase DB

    global.DB.loadProviders().then(function(items) {
      
        // Getting the registered providers

        var providers = [];

        for (var i = 0; i < items.length; i++) {
            if (items[i].selected) {
                providers.push(items[i]);
            }
        }

        // Sorting the providers based on the selected sort type

        providers.sort(function(a, b) {
            if (sorttype === global.CONST.BUTTON.SORTBYPOINT) {
                return (b.balance || 0) - (a.balance || 0);            
            } else {
                if (a.name < b.name) {
                    return -1;
                } else if (a.name > b.name) {
                    return 1;
                } else {
                    return 0;
                }
            }
        });

        // Clearing screen content

        providerContainer.removeChildren();
    
        // Appending the registered providers
        
        for (var i = 0; i < providers.length; i++) {
            providerContainer.addChild(createProvider(providers[i], i));
        }

        // Appending the ADD button

        providerContainer.addChild(createAddButton(providers.length));

        // Appending empty providers if some space left

        if (((providers.length + 1) / 2) < numberOfRows) {
            for (var i = providers.length + 1; i < numberOfRows * 2; i++) {
                providerContainer.addChild(createEmptyProvider(i));
            }
        }        
    });
};
