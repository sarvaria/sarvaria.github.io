'use strict';

/*
Copyright (C) 2017 Andras Sarvari <andras.sarvari@sarvaria.net>

Permission to use, copy, modify, and/or distribute this software for any
purpose with or without fee is hereby granted, provided that the above
copyright notice and this permission notice appear in all copies.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
*/

// Declaring module level variables

var container;
var actionBarTitle;
var leftButton;
var settingsButton;

/**
 * Event that fires when the actionbar has been loaded.
 * 
 * @param   event {Object}      event object
 */

exports.onLoaded = function(event) {

    // Getting the container and propagating the public methods

    container = event.object;
    container.setTitle = exports.setTitle;
    container.getLeftButton = exports.getLeftButton;
    container.setLeftButton = exports.setLeftButton;
    container.setSettingsButton = exports.setSettingsButton;

    // Getting the referenced widgets in the container

    actionBarTitle = container.getViewById('title');
    leftButton = container.getViewById('leftbutton');
    settingsButton = container.getViewById('settingsbutton');
};

/**
 * Sets the title of the actionbar.
 * 
 * @param   title {String}      title of the actionbar
 */

exports.setTitle = function(title) {
    
    // Setting actionbar title

    actionBarTitle.text = title;
};

/**
 * Gets the left button.
 * 
 * @return  leftbutton {String} left button type
 */

exports.getLeftButton = function() {

    // Getting the left button type

    return leftButton.className;
};

/**
 * Sets the left button.
 * 
 * @param   icon {String}       icon type
 */

exports.setLeftButton = function(icon) {

    // Refreshing the left button

    leftButton.className = icon;

    if (icon == undefined) {
        leftButton.visibility = 'collapse';
        container.backButton = false;
    } else if (icon == 'back') {
        leftButton.src = 'res://back';
        leftButton.visibility = 'visible';
        container.backButton = true;
    } else if (icon == 'sortbypoint') {
        leftButton.src = 'res://sortbalance';
        leftButton.visibility = 'visible';
        container.backButton = false;
    } else if (icon == 'sortbyalphabet') {
        leftButton.src = 'res://sortaz';
        leftButton.visibility = 'visible';
        container.backButton = false;
    }
};

/**
 * Sets the settings button.
 * 
 * @param   selected {Boolean}  selection state of the button
 */

exports.setSettingsButton = function(selected) {

    // Refreshing the settings button

    if (selected == undefined) {
        settingsButton.visibility = 'collapse';
    } else if (selected) {
        settingsButton.src = 'res://settings_selected';
        settingsButton.visibility = 'visible';
    } else {
        settingsButton.src = 'res://settings_unselected';
        settingsButton.visibility = 'visible';
    }
};

/**
 * Event that fires when the left button tapped.
 * 
 * @param   event {Object}      event object
 */

exports.leftButtonTapped = function(event) {

    // Does any left button available?

    if (leftButton.visibility == 'visible') {

        // Firing the event

        if (leftButton.className) {
            container.notify({
                eventName:  leftButton.className + 'buttonselected' 
            });
        }
    }
};

/**
 * Event that fires when the settings button tapped.
 * 
 * @param   event {Object}      event object
 */

exports.settingsButtonTapped = function(event) {

    // Does the settings button available?

    if (settingsButton.visibility == 'visible') {

        // Selecting the settings button

        exports.setSettingsButton(true);

        // Firing the "settingsselected" event

        container.notify({
            eventName:  'settingsselected'
        });
    }
};
