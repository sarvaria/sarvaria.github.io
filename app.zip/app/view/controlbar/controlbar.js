'use strict';

/*
Copyright (C) 2017 Andras Sarvari <andras.sarvari@sarvaria.net>

Permission to use, copy, modify, and/or distribute this software for any
purpose with or without fee is hereby granted, provided that the above
copyright notice and this permission notice appear in all copies.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
*/

// Declaring constanses

const CONTROLBUTTON = ['map', 'notification', 'search', 'favorites'];
const EVENT_CONTROLBUTTON_SELECTED = 'controlbuttonselected';

// Declaring module level variables

var container;

/**
 * Event that fires when the controlbar has been loaded.
 * 
 * @param   event {Object}      event object
 */

exports.onLoaded = function(event) {

    // Getting the container and propagating the public methods

    container = event.object;
    container.setUnreadNotification = exports.setUnreadNotification;
    container.selectButton = exports.selectButton;
};

/**
 * Shows or hides the unread notification flag on the notification control
 * button.
 * 
 * @param   unred {Boolean}     unread notification flag
 */

exports.setUnreadNotification = function(unread) {
    exports.hasUnreadNotification = unread;
    exports.selectButton(exports.selectedButton);
};

/**
 * Event that fires when a control button tapped.
 * 
 * @param   event {Object}      event object
 */

exports.buttonTapped = function(event) {

    // Getting the tapped button ID

    var id = event.object.getChildAt(0).id;

    // Does the requested button ID is different than the current one?
    // If yes, selecting the button.

    if (exports.selectedButton !== id) {
        exports.selectButton(id);
    }
};

/**
 * Selects the specified control button by id if the current button is
 * different.
 * 
 * @param   id  {String}    ID of the button
 */

exports.selectButton = function(id) {

    // Deselected all of the control buttons

    CONTROLBUTTON.forEach(function(button) {
        if (button !== id) {
            container.getViewById(button).src = 'res://' + button + 
                                                '_unselected' + 
                                                (button === 'notification' ? 
                                                (exports.hasUnreadNotification ?
                                                '_unread' : '') : '');
        }
    });

    // Selecting and registering the control button

    var sb = container.getViewById(id);

    if (sb) {
        sb.src = 'res://' + id + '_selected' + (id === 'notification' ? 
                 (exports.hasUnreadNotification ? '_unread' : '') : '');
    }

    exports.selectedButton = id;

    // Firing the "controlbuttonselected" event
    
    container.notify({
        eventName:  EVENT_CONTROLBUTTON_SELECTED,
        id:         id
    });
};
