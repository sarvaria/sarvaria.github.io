'use strict';

/*
Copyright (C) 2017 Andras Sarvari <andras.sarvari@sarvaria.net>

Permission to use, copy, modify, and/or distribute this software for any
purpose with or without fee is hereby granted, provided that the above
copyright notice and this permission notice appear in all copies.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
*/

// Loading required modules

var enums = require('ui/enums');
var StackLayout = require('ui/layouts/stack-layout').StackLayout;
var imageModule = require('ui/image');
var labelModule = require('ui/label');

/**
 * Creates a new BarChart object.
 */

var BarChart = function() {};

/**
 * Refreshes the chart based on the specified data.
 * 
 * @param   data    {Array} data    array of the barchart column data
 */

BarChart.prototype.refresh = function(parent, data) {

    var hour = new Date().getHours();

    parent.removeChildren();

    var container = new StackLayout();
    container.orientation = 'vertical';

    var chartData = new StackLayout();
    chartData.orientation = 'horizontal';
    
    var barWidth = parseInt(((global.screenSize.widthDP - 32 - 32 - (18 * 2)) / 18) * 0.99);
    var maxHeight = 76;
    var maxValue = Math.max.apply(null, data);
    var bw = (100 / 18) * 0.881;

    chartData.height = maxHeight + 'dp';

    for (var i = 0; i < data.length; i++) {
        var stackLayout = new StackLayout();

        if (i + 6 == hour) {
            stackLayout.style['background-color'] = '#F76830';
        } else {
            stackLayout.style['background-color'] = '#35b28a';
        }

        stackLayout.style['border-top-left-radius'] = '4dp';
        stackLayout.style['border-top-right-radius'] = '4dp';

        if (i == 0) {
            stackLayout.style.margin = '0dp 1dp 0dp 3dp';
        } else {
            stackLayout.style.margin = '0dp 1dp 0dp 1dp';
        }

        stackLayout.width = bw + '%';
        stackLayout.height = ((data[i] / maxValue) * maxHeight) + 'dp';
        stackLayout.verticalAlignment = enums.VerticalAlignment.bottom;

        chartData.addChild(stackLayout);
    }

    container.addChild(chartData);

    var barline = new StackLayout();
    barline.className = 'barline';
    container.addChild(barline);

    var timeline = new imageModule.Image();
    timeline.src = 'res://timeline';
    timeline.width = '100%';
    container.addChild(timeline);

    var timeContainer = new StackLayout();
    timeContainer.orientation = 'horizontal';

    var timeMargin = new labelModule.Label();
    timeMargin.text = '';
    timeMargin.className = 'bartime';
    timeMargin.width = '8.8%';
    timeMargin.height = '16dp';
    timeMargin.verticalAlignment = 'center';
    timeContainer.addChild(timeMargin);

    var times = ['09:00', '12:00', '15:00', '18:00', '21:00'];

    for (var i = 0; i < times.length; i++) {
        var time = new labelModule.Label();
        time.text = times[i];
        time.className = 'bartime';
        time.width = '16.6%';
        time.height = '16dp';
        time.verticalAlignment = 'center';
        timeContainer.addChild(time);
    }

    container.addChild(timeContainer);

    parent.addChild(container);
};

// Propagating the bar chart

exports.BarChart = BarChart;
